import * as L from 'leaflet';

declare module 'leaflet' {
    namespace vectorGrid {
        interface VectorGridOptions {
            vectorTileLayerStyles?: object;
            interactive?: boolean;
            getFeatureId?: any;
            rendererFactory?: number;
        }

        interface ProtobufOptions extends VectorGridOptions {
            subdomains?: string;
            fetchOptions?: Request;
        }

        interface SlicerOptions extends VectorGridOptions {
            vectorTileLayerName: string;
            extent?: number;
            maxZoom?: number;
        }

        interface Protobuf extends VectorGrid {
            options: ProtobufOptions;
            setUrl(url: string, noRedraw?: boolean): Protobuf;
        }

        interface Slicer extends VectorGrid {
            options: SlicerOptions;
        }

        interface VectorGrid extends GridLayer {
            options?: VectorGridOptions;
            initialize(options: VectorGridOptions): void;
            setFeatureStyle(id: number, layerStyle: PathOptions): VectorGrid;
            resetFeatureStyle(id: number): VectorGrid;
            getDataLayerNames(): Array<string>;
        }

        function protobuf(url: string, options: VectorGridOptions): Protobuf;
        function slicer(geojson: L.GeoJSON, options: SlicerOptions): Slicer;
    }

    namespace renderer {
        namespace SVG {
            interface Tile {
                initialize(
                    tileCoord: Array<number>,
                    tileSize: number,
                    options: RendererOptions,
                ): void;
                getCoord(): void;
                getContainer(): void;
                onAdd: any;
                addTo(map: Map): Tile;
                removeFrom(map: Map): Tile;
            }

            function tile(
                tileCoord: Array<number>,
                tileSize: number,
                options: RendererOptions,
            ): void;
        }

        namespace canvas {
            interface Tile {
                initialize(
                    tileCoord: Array<number>,
                    tileSize: number,
                    options: TileLayerOptions,
                ): void;
                getCoord(): void;
                getContainer(): void;
                getOffset(): void;
                onAdd: any;
                addTo(map: Map): Tile;
                removeFrom(map: Map): Tile;
            }

            function tile(
                tileCoord: Array<number>,
                tileSize: number,
                options: RendererOptions,
            ): void;
        }
    }
}
