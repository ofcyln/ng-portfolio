import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'rdm-qrid-actions',
    templateUrl: './qrid-actions.component.html',
    styleUrls: ['./qrid-actions.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class QridActionsComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
