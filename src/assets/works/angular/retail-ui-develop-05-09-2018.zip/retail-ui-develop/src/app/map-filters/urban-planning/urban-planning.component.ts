import { Component, HostBinding, OnInit } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';

@Component({
    selector: 'rdm-urban-planning',
    templateUrl: './urban-planning.component.html',
    styleUrls: ['./urban-planning.component.scss'],
    animations: [slideInLeftAnimation],
})
export class UrbanPlanningComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    constructor() {}

    ngOnInit() {}
}
