import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QridActionsComponent } from './qrid-actions.component';

describe('QridActionsComponent', () => {
    let component: QridActionsComponent;
    let fixture: ComponentFixture<QridActionsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [QridActionsComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(QridActionsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
