import { Component, HostBinding, OnInit } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment';
import { Settings } from 'daterangepicker';
import { DropdownSettings } from 'angular2-multiselect-dropdown/multiselect.interface';
import { ProjectsResponse, PropertiesResponse, ResidenceService } from './residence.service';

export interface ResidencePriceType {
    title: string;
    id: number;
}

export interface ListItem {
    id: Number;
    itemName: String;
}

export interface GroupedListItem extends ListItem {
    category: string;
}

export interface DateRangeModel {
    start?: string | Date | moment.Moment;
    end?: string | Date | moment.Moment;
    label?: string;
}

@Component({
    selector: 'rdm-residence',
    templateUrl: './residence.component.html',
    styleUrls: ['./residence.component.scss'],
    animations: [slideInLeftAnimation],
    providers: [ResidenceService],
})
export class ResidenceComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    public groupedMultiselectSettings: DropdownSettings;
    public multiselectSettings: DropdownSettings;

    public selectedResidencePriceType = 'Select Price Type';

    public residencePriceTypes: ResidencePriceType[] = [
        { title: '1. El Satış TL / m²', id: 0 },
        { title: '1. El Satış', id: 1 },
        { title: 'Kira m²', id: 2 },
        { title: '2. El Satış TL / m²', id: 3 },
        { title: '2. El Satış', id: 4 },
    ];

    // daterangepicker
    public selectedStartDateRange: DateRangeModel = {};
    public selectedEndDateRange: DateRangeModel = {};
    public dateRangePickerSettings: Settings;

    // multiselect
    public residenceCategories: ListItem[] = [];
    public selectedResidenceCategories: ListItem[];

    public residenceStatuses: ListItem[] = [];
    public selectedResidenceStatuses: ListItem[];

    public residenceTypes: GroupedListItem[] = [];
    public selectedResidenceTypes: GroupedListItem[];

    public showDetailedFilter: boolean = false;

    constructor(
        public translateService: TranslateService,
        public translate: TranslateService,
        public residenceService: ResidenceService,
    ) {}

    ngOnInit() {
        this.initDateRangePickerSettings();
        this.initMultiselectSettings();
        this.initMultiselectData();

        this.translateService
            .stream('main.general.placeholders.select')
            .subscribe((translatedText) => (this.multiselectSettings.text = translatedText));

        this.residenceService.getProjects().then((projects: ProjectsResponse) => {
            this.residenceCategories = this.residenceService.objectToMultiselectData(
                projects.ProjectType,
            );
            this.residenceStatuses = this.residenceService.objectToMultiselectData(
                projects.StatusID,
            );
        });
    }

    public onDateSelection(value: DateRangeModel, dateRangeModel?: DateRangeModel): void {
        dateRangeModel.start = value.start;
        dateRangeModel.end = value.end;
        dateRangeModel.label = value.label;
    }

    // multiselect methods
    public onItemSelect(item: ListItem): void {
        console.log(item);
    }

    public onItemDeSelect(item: ListItem): void {
        console.log(item);
    }

    public onSelectAll(items: ListItem[]): void {
        console.log(items);
    }

    public onDeSelectAll(items: ListItem[]): void {
        console.log(items);
    }

    // dropdown assigns
    public setResidencePriceType(residencePriceTypes: ResidencePriceType): void {
        this.selectedResidencePriceType = residencePriceTypes.title;
    }

    private initMultiselectSettings(): void {
        this.multiselectSettings = {
            singleSelection: false,
            text: 'Select',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            searchPlaceholderText: 'Select Options',
            enableSearchFilter: false,
            badgeShowLimit: 1,
            enableCheckAll: true,
            maxHeight: 200,
            classes: '',
            noDataLabel: '',
            primaryKey: '',
            searchBy: [],
            position: '',
        };

        this.groupedMultiselectSettings = {
            singleSelection: false,
            text: 'Select',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            searchPlaceholderText: 'Select Options',
            enableSearchFilter: false,
            badgeShowLimit: 1,
            groupBy: 'category',
            enableCheckAll: true,
            maxHeight: 200,
            classes: '',
            noDataLabel: '',
            primaryKey: '',
            searchBy: [],
            position: '',
        };
    }

    private initMultiselectData(): void {
        this.residenceService.getProperties().then((properties: PropertiesResponse) => {
            this.residenceTypes = this.residenceService.objectToGroupMultiselectData(
                properties.SubTypeID,
            );
        });
    }

    private initDateRangePickerSettings(): void {
        this.dateRangePickerSettings = {
            locale: {
                format: 'DD/MM/YYYY',
                separator: ' - ',
                customRangeLabel: 'Custom Range',
                applyLabel: 'Apply',
                cancelLabel: 'Cancel',
                weekLabel: 'W',
                daysOfWeek: ['Pz', 'Pzt', 'Sa', 'Çar', 'Per', 'Cu', 'Cst'],
                monthNames: [
                    'Ocak',
                    'Şubat',
                    'Mart',
                    'Nisan',
                    'Mayıs',
                    'Haziran',
                    'Temmuz',
                    'Ağustos',
                    'Eylül',
                    'Ekim',
                    'Kasım',
                    'Aralık',
                ],
                firstDay: 1,
            },
            alwaysShowCalendars: false,
            showCustomRangeLabel: true,
            linkedCalendars: false,
            showDropdowns: true,
            ranges: {
                Today: [moment(), moment()],
                Yesterday: [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [
                    moment()
                        .subtract(1, 'month')
                        .startOf('month'),
                    moment()
                        .subtract(1, 'month')
                        .endOf('month'),
                ],
            },
        };
    }
}
