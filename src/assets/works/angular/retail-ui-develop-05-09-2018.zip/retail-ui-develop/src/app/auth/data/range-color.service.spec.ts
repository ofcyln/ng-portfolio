import { TestBed, inject } from '@angular/core/testing';

import { RangeColorService } from './range-color.service';

describe('RangeColorService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [RangeColorService],
        });
    });

    it('should be created', inject([RangeColorService], (service: RangeColorService) => {
        expect(service).toBeTruthy();
    }));
});
