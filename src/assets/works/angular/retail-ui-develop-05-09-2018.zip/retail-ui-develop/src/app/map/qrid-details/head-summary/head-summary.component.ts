import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MapService } from '../../../shared/map.service';
import { UserPreferenceService } from '../../../auth/user/user-preference.service';

@Component({
    selector: 'rdm-head-summary',
    templateUrl: './head-summary.component.html',
    styleUrls: ['./head-summary.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class HeadSummaryComponent implements OnInit {
    constructor(
        public mapService: MapService,
        public userPreferencesService: UserPreferenceService,
    ) {}

    ngOnInit() {}
}
