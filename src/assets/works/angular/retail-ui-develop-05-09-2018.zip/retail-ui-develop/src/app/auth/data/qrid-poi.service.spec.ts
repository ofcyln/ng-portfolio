import { TestBed, inject } from '@angular/core/testing';

import { QridPoiService } from './qrid-poi.service';

describe('QridPoiService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [QridPoiService],
        });
    });

    it('should be created', inject([QridPoiService], (service: QridPoiService) => {
        expect(service).toBeTruthy();
    }));
});
