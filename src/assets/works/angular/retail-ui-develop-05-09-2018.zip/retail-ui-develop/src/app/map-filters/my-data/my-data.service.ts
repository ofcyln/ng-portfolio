import { Injectable } from '@angular/core';
import { MapService } from '../../shared/map.service';
import * as L from 'leaflet';
import { Marker } from 'leaflet';
import { LayerGroup } from 'leaflet';
import { UserFilesResponse } from '../../auth/data/user-files.service';

export interface UserFileResponseExtended extends UserFilesResponse {
    selectedFileItem: boolean;
}

@Injectable({
    providedIn: 'root',
})
export class MyDataService {
    public selectedUploadMyDataItem: boolean;
    public selectedUploadMyDataItems: boolean = false;

    public markerLayerContainer: LayerGroup;

    constructor(public mapService: MapService) {}

    public iterateMarkers(latLonName: any): void {
        let placeMarker: Marker;

        this.markerLayerContainer = L.layerGroup();

        for (let marker of latLonName) {
            let lat = marker[0];
            let lon = marker[1];
            let name = marker[2];

            placeMarker = new L.Marker(new L.LatLng(lat, lon), {
                icon: L.divIcon({
                    className: 'leaflet-marker-icon ricon-pin-full',
                }),
            })
                .bindPopup(name, {
                    className: 'marker-popup',
                })
                .on('mouseover', function() {
                    this.openPopup();
                })
                .on('mouseout', function() {
                    this.closePopup();
                })
                .addTo(this.markerLayerContainer);
        }

        this.mapService.map.addLayer(this.markerLayerContainer);

        this.mapService.map.setView([41.03513764127896, 29.027089923620228], 10);
    }

    public setMarkerBoundryPoints() {}
}
