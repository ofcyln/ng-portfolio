import { Injectable } from '@angular/core';
import { UserPreferenceService } from '../user/user-preference.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface QridDetailsHeadResponse {
    CityID: number;
    CityName: string;
    CountyID: number;
    CountyName: string;
    DistrictID: number;
    DistrictName: string;
    Poi_Score: number;
    Population_Score: number;
    RehexID: number;
    Rehex_Score: number;
    Social_Score: number;
    Transport_Score: number;
}

@Injectable()
export class QridDetailsHeadService {
    constructor(public http: HttpClient, public userPreferenceService: UserPreferenceService) {}

    public getQridDetailsHeadSummary(rehexID: number): Observable<QridDetailsHeadResponse> {
        return this.http.get<QridDetailsHeadResponse>(
            `${environment.contentAPIUrl}/api/v1/qrid/info/${
                this.userPreferenceService.userSettings.countryCode
            }/${rehexID}`,
        );
    }
}
