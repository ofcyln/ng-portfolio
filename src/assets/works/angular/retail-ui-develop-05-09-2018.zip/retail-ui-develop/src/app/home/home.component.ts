import { Component, OnInit } from '@angular/core';
import { UserPreferenceService } from '../auth/user/user-preference.service';

@Component({
    selector: 'rdm-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
    // @HostBinding('class.AE') regionClass: string;
    constructor(public userPreferenceService: UserPreferenceService) {}

    ngOnInit() {}

    // public onClick(flag: boolean) {
    //     console.log(`Output Works and It's ${flag}`);
    // }
}
