import { Component, OnInit } from '@angular/core';
import { UserPreferenceService } from '../auth/user/user-preference.service';

@Component({
    selector: 'rdm-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
    // @Input('title') fikret: string; // inputa default string vermezsen yanindaki property adini alir tasir
    // @Output() click = new EventEmitter<boolean>(); // output bir deger bekler ve donus tipini gecmen gerekir

    public region: string = this.userPreferencesService.userSettings.countryCode || 'TR';

    constructor(public userPreferencesService: UserPreferenceService) {}

    ngOnInit() {}

    public changedRegion(region: string) {
        this.region = region;
    }

    // public onClick() {
    //     this.click.emit(true); // parent a haber verecek, emit methoduna deger gecebilirsin
    // }
}
