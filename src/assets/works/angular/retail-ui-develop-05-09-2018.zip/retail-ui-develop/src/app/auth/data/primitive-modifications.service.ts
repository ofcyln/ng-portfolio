import { Injectable } from '@angular/core';
import { UserPreferenceService } from '../user/user-preference.service';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
    providedIn: 'root',
})
export class PrimitiveModificationsService {
    constructor(
        public userPreferenceService: UserPreferenceService,
        public translateService: TranslateService,
    ) {}

    public modifyNumber(value: number) {
        if (value > 0 && value < 100) {
            return value.toFixed(2);
        } else if (value >= 100 && value < 1000) {
            return value.toFixed(1);
        } else if (value >= 1000 && value < 10000) {
            return value.toFixed();
        } else if (value >= 10000 && value < 1000000) {
            if (this.userPreferenceService.userSettings.language === 'tr') {
                return (value / 1000).toFixed(2) + 'b';
            } else {
                return (value / 1000).toFixed(2) + 'k';
            }
        } else if (value > 1000000) {
            return (value / 100000).toFixed(2) + 'M';
        } else if (value === 0) {
            return 0;
        } else {
            return value;
        }
    }

    public capitalizeEachWord(word: string) {
        return word.replace(/\w\S*/g, (newWord) => {
            return `${newWord.charAt(0).toUpperCase()}${newWord.substr(1).toLowerCase()}`;
        });
    }

    public semanticNamesOfMonths(response: string[]) {
        return response.map((item: string) => {
            switch (item) {
                case '01':
                case '02':
                case '03':
                case '04':
                case '05':
                case '06':
                case '07':
                case '08':
                case '09':
                case '10':
                case '11':
                case '12':
                    return this.translateService.instant(`main.general.misc.months.${item}`);
                    break;
                default:
                    return 'Error';
                    break;
            }
        });
    }
}
