import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home.component';
import { MapModule } from '../map/map.module';
import { SidebarModule } from '../sidebar/sidebar.module';
import { HeaderModule } from '../header/header.module';
import { MapFiltersModule } from '../map-filters/map-filters.module';
import { ResidenceComponent } from '../map-filters/residence/residence.component';
import { OfficeComponent } from '../map-filters/office/office.component';
import { MarketAnalysisComponent } from '../map-filters/market-analysis/market-analysis.component';
import { UrbanPlanningComponent } from '../map-filters/urban-planning/urban-planning.component';
import { TransactionComponent } from '../map-filters/transaction/transaction.component';
import { PoiComponent } from '../map-filters/poi/poi.component';
import { WorkspaceComponent } from '../map-filters/workspace/workspace.component';
import { LayerComponent } from '../map-filters/layer/layer.component';
import { ListingsComponent } from '../map-filters/listings/listings.component';
import { MapTypeComponent } from '../map-filters/map-type/map-type.component';
import { CustomizationComponent } from '../map-filters/customization/customization.component';
import { QridLayersComponent } from '../map-filters/qrid-layers/qrid-layers.component';
import { AuthGuard } from '../auth/auth.component';
import { RivalsDataComponent } from '../map-filters/rivals-data/rivals-data.component';
import { MyDataComponent } from '../map-filters/my-data/my-data.component';

const router: Routes = [
    {
        path: 'home',
        component: HomeComponent,
        children: [
            { path: 'residence', component: ResidenceComponent },
            { path: 'office', component: OfficeComponent },
            { path: 'market-analysis', component: MarketAnalysisComponent },
            { path: 'urban-planning', component: UrbanPlanningComponent },
            { path: 'transaction', component: TransactionComponent },
            { path: 'poi', component: PoiComponent },
            { path: 'workspace', component: WorkspaceComponent },
            { path: 'layer', component: LayerComponent },
            { path: 'listings', component: ListingsComponent },
            { path: 'map-type', component: MapTypeComponent },
            { path: 'customization', component: CustomizationComponent },
            { path: 'qrid-layers', component: QridLayersComponent },
            { path: 'my-data', component: MyDataComponent },
            { path: 'rivals-data', component: RivalsDataComponent },
        ],
        canActivate: [AuthGuard],
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(router),
        HeaderModule,
        SidebarModule,
        MapModule,
        MapFiltersModule,
    ],
    exports: [RouterModule, HeaderModule, SidebarModule, MapModule, MapFiltersModule],
})
export class HomeRoutingModule {}
