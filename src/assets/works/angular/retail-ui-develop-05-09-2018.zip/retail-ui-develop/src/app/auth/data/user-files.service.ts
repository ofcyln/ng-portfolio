import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface UserFilesResponse {
    fileid: string;
    filename: string;
    file_alias: string;
    rival: boolean;
    active: boolean;
    username: string;
}

export interface UserFileResponse {
    fileid: string;
    filename: string;
    file_alias: string;
    rival: boolean;
    active: boolean;
    username: string;
    row_count: number;
    rows: UserFileRows[];
}

export interface UserFileRows {
    name: string;
    latitude: number;
    longitude: number;
    extra_data: UserFileExtraData;
}

export interface UserFileExtraData {
    Type: string;
    GLA: number;
    Revenue: number;
    Tier: number;
    Outdoor: number;
    Textile: number;
    Furniture: number;
    Notes: string;
}

export interface DeleteFileResponse {
    Deleted: number;
}

export interface PatchFileResponse {
    Updated: number;
}

@Injectable({
    providedIn: 'root',
})
export class UserFilesService {
    private patchFileBody: FormData;

    constructor(public http: HttpClient) {}

    public getUserFiles(): Observable<UserFilesResponse[]> {
        return this.http.get<UserFilesResponse[]>(`${environment.contentAPIUrl}/api/v1/user/file/`);
    }

    public getUserFile(fileID: string): Observable<UserFileResponse> {
        return this.http.get<UserFileResponse>(
            `${environment.contentAPIUrl}/api/v1/user/file/${fileID}`,
        );
    }

    public deleteUserFile(fileID: string): Observable<DeleteFileResponse> {
        return this.http.delete<DeleteFileResponse>(
            `${environment.contentAPIUrl}/api/v1/user/file/${fileID}`,
        );
    }

    public patchUserFile(fileID: string, fileAlias: string): Observable<PatchFileResponse> {
        this.patchFileBody = new FormData();

        this.patchFileBody.append('file_alias', fileAlias);

        return this.http.patch<PatchFileResponse>(
            `${environment.contentAPIUrl}/api/v1/user/file/${fileID}`,
            this.patchFileBody,
        );
    }
}
