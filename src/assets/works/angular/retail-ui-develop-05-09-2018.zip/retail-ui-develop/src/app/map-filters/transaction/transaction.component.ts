import { Component, HostBinding, OnInit } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';
import * as moment from 'moment';
import { Settings } from 'daterangepicker';

export interface Transactions {
    title: string;
    id: number;
}

export interface DateRangeModel {
    start?: string | Date | moment.Moment;
    end?: string | Date | moment.Moment;
    label?: string;
}

@Component({
    selector: 'rdm-transaction',
    templateUrl: './transaction.component.html',
    styleUrls: ['./transaction.component.scss'],
    animations: [slideInLeftAnimation],
})
export class TransactionComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    public transactionsMapActive: boolean = false;

    public selectedPropertyType = 'Select Property Type';
    public propertyTypes: Transactions[];

    public selectedResourceType = 'Select Resource';
    public resourceTypes: Transactions[];

    // daterangepicker
    public selectedStartDateRange: DateRangeModel = {};
    public dateRangePickerSettings: Settings;
    public transactionsOptionsActive: boolean;

    constructor() {}

    ngOnInit() {
        this.initDateRangePickerSettings();
        this.initTransactionData();
    }

    public onDateSelection(value: DateRangeModel, dateRangeModel?: DateRangeModel): void {
        dateRangeModel.start = value.start;
        dateRangeModel.end = value.end;
        dateRangeModel.label = value.label;
    }

    private initTransactionData() {
        this.propertyTypes = [
            {
                title: 'Apartman',
                id: 1,
            },
            {
                title: 'Ofis',
                id: 2,
            },
            {
                title: 'İş Yeri',
                id: 3,
            },
        ];

        this.resourceTypes = [
            {
                title: 'Resource 1',
                id: 1,
            },
            {
                title: 'Resource 2',
                id: 2,
            },
        ];
    }

    private initDateRangePickerSettings(): void {
        this.dateRangePickerSettings = {
            locale: {
                format: 'DD/MM/YYYY',
                separator: ' - ',
                customRangeLabel: 'Custom Range',
                applyLabel: 'Apply',
                cancelLabel: 'Cancel',
                weekLabel: 'W',
                daysOfWeek: ['Pz', 'Pzt', 'Sa', 'Çar', 'Per', 'Cu', 'Cst'],
                monthNames: [
                    'Ocak',
                    'Şubat',
                    'Mart',
                    'Nisan',
                    'Mayıs',
                    'Haziran',
                    'Temmuz',
                    'Ağustos',
                    'Eylül',
                    'Ekim',
                    'Kasım',
                    'Aralık',
                ],
                firstDay: 1,
            },
            singleDatePicker: true,
            alwaysShowCalendars: false,
            showCustomRangeLabel: true,
            linkedCalendars: false,
            showDropdowns: true,
            ranges: {
                Today: [moment(), moment()],
                Yesterday: [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [
                    moment()
                        .subtract(1, 'month')
                        .startOf('month'),
                    moment()
                        .subtract(1, 'month')
                        .endOf('month'),
                ],
            },
        };
    }
}
