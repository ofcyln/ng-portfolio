import {
    Component,
    HostBinding,
    Input,
    OnChanges,
    OnInit,
    SimpleChanges,
    ViewEncapsulation,
} from '@angular/core';
import { MapService } from '../../shared/map.service';
import { QridPopulationResponse } from '../../auth/data/qrid-population.service';

@Component({
    selector: 'rdm-qrid-details',
    templateUrl: './qrid-details.component.html',
    styleUrls: ['./qrid-details.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class QridDetailsComponent implements OnInit, OnChanges {
    @HostBinding('class') classes = 'qrid-filter-pane';
    @Input() populationDemography: QridPopulationResponse = this.mapService.populationDemography;

    constructor(public mapService: MapService) {
        // console.log(this.mapService.populationDemography);
        // console.log(this.mapService.propertyRehexID);
    }

    ngOnChanges(changes: SimpleChanges) {
        // console.log('ngOnChange', changes, 'ngOnChange populationDemography',changes['populationDemography']);
    }

    ngOnInit() {}

    public toggleDetailScreen() {
        this.mapService.toggleDetailsScreen = !this.mapService.toggleDetailsScreen;
    }
}
