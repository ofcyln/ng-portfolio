import { Component, HostBinding, OnInit, ViewEncapsulation } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';

@Component({
    selector: 'rdm-rivals-data',
    templateUrl: './rivals-data.component.html',
    styleUrls: ['./rivals-data.component.scss'],
    animations: [slideInLeftAnimation],
    encapsulation: ViewEncapsulation.None,
})
export class RivalsDataComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    constructor() {}

    ngOnInit() {}
}
