import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogoComponent } from './logo/logo.component';
import { SearchBarComponent } from './search-bar/search-bar.component';
import { PreferencesMenuComponent } from './preferences-menu/preferences-menu.component';
import { LogoutButtonComponent } from './logout-button/logout-button.component';
import { HeaderComponent } from './header.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Ng2CompleterModule } from 'ng2-completer';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        NgbModule,
        Ng2CompleterModule,
        FormsModule,
        TranslateModule,
    ],
    declarations: [
        LogoComponent,
        SearchBarComponent,
        PreferencesMenuComponent,
        LogoutButtonComponent,
        HeaderComponent,
    ],
    exports: [
        LogoComponent,
        SearchBarComponent,
        PreferencesMenuComponent,
        LogoutButtonComponent,
        HeaderComponent,
    ],
})
export class HeaderModule {}
