import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MapService } from '../../../../shared/map.service';

@Component({
    selector: 'rdm-education',
    templateUrl: './education.component.html',
    styleUrls: ['./education.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class EducationComponent implements OnInit {
    constructor(public mapService: MapService) {}

    ngOnInit() {}

    public totalHighSchool() {
        return (
            this.mapService.populationDemography.HighSchool +
            this.mapService.populationDemography.ElementarySchool +
            this.mapService.populationDemography.SecondarySchool
        );
    }
}
