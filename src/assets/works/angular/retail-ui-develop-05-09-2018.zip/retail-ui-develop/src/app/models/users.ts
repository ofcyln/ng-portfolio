export interface LoginResponse {
    access_token: string;
    expires_in: number;
    client_id: string;
    device_id: string;
    expired_at: string;
    token_type: string;
    code?: string;
    message?: string;
    user: User;
}

export interface User {
    admin: boolean;
    closed: boolean;
    company: null | string;
    created_at: string;
    crm_user_id: null | string;
    email: string;
    id: number;
    is_active: boolean;
    logout_option: boolean;
    mobile_option: boolean;
    mobile_phone: null | string;
    multiple_device_option: boolean;
    name: string;
    products?: Product[];
    session_count: number;
    status: boolean;
    updated_at: null | string;
}

export interface Product {
    code?: string;
    country?: string;
    crm_product_id?: null | number;
    end_date?: string;
    id?: number;
    name?: string;
    product_type?: {
        code: string;
        default_credit: number;
        id: number;
        name: string;
        sort_key: number;
    };
    start_date?: string;
    user_id?: number;
}

// export interface APIResponse<T> {
//     code: number;
//     message: string;
//     data: T;
// }

export interface RequestParameters {
    device_id: number;
    username?: string;
    password?: string;
    grant_type: string;
}

export interface Alert {
    type: AlertType;
    message: string;
}

export enum AlertType {
    Success,
    Error,
    Info,
    Warning,
}
