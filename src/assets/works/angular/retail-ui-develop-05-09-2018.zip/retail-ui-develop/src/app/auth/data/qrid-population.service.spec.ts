import { TestBed, inject } from '@angular/core/testing';

import { QridPopulationService } from './qrid-population.service';

describe('QridPopulationService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [QridPopulationService],
        });
    });

    it('should be created', inject([QridPopulationService], (service: QridPopulationService) => {
        expect(service).toBeTruthy();
    }));
});
