import { NgModule } from '@angular/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AuthGuard } from './auth.component';
import { JwtInterceptor } from '../helpers/jwt-interceptor';
import { AuthenticationService } from './authentication.service';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { LoginRoutingModule } from './login/login-routing.module';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { UserPreferenceService } from './user/user-preference.service';
import { AlertModule } from '../alert/alert.module';

@NgModule({
    imports: [
        CommonModule,
        LoginRoutingModule,
        FormsModule,
        NgbModule,
        AlertModule,
        TranslateModule,
        RouterModule,
    ],
    declarations: [LoginComponent],
    providers: [
        AuthGuard,
        AuthenticationService,
        UserPreferenceService,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: JwtInterceptor,
            multi: true,
        },
    ],
    exports: [LoginRoutingModule],
})
export class AuthModule {}
