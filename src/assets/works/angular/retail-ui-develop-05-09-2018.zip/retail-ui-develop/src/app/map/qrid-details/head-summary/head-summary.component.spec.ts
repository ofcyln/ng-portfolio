import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeadSummaryComponent } from './head-summary.component';

describe('HeadSummaryComponent', () => {
    let component: HeadSummaryComponent;
    let fixture: ComponentFixture<HeadSummaryComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HeadSummaryComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HeadSummaryComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
