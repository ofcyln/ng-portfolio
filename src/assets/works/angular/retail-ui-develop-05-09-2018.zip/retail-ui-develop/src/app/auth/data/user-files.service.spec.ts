import { TestBed, inject } from '@angular/core/testing';

import { UserFilesService } from './user-files.service';

describe('UserFilesService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [UserFilesService],
        });
    });

    it('should be created', inject([UserFilesService], (service: UserFilesService) => {
        expect(service).toBeTruthy();
    }));
});
