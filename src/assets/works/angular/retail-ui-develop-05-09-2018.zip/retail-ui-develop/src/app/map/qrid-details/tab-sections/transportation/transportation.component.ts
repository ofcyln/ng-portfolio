import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { MapService } from '../../../../shared/map.service';
import { QridTransportationResponse } from '../../../../auth/data/qrid-transportation.service';

@Component({
    selector: 'rdm-transportation',
    templateUrl: './transportation.component.html',
    styleUrls: ['./transportation.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class TransportationComponent implements OnInit {
    public transportationItems: Array<QridTransportationResponse> = this.mapService
        .qridTransportationSummary;

    constructor(public mapService: MapService, public translateService: TranslateService) {}

    ngOnInit() {}
}
