import { Component, HostBinding, OnInit, ViewEncapsulation } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';
import { UserPreferenceService, UserSettings } from '../../auth/user/user-preference.service';
import { MapService } from '../../shared/map.service';
import { UserService } from '../../auth/user/user.service';
import { User } from '../../models/users';
import { QridLayersService } from './qrid-layers.service';

@Component({
    selector: 'rdm-qrid-layers',
    templateUrl: './qrid-layers.component.html',
    styleUrls: ['./qrid-layers.component.scss'],
    animations: [slideInLeftAnimation],
    encapsulation: ViewEncapsulation.None, // :host ya da :host::ng-deep kullanmadan style yedirmek icin
})
export class QridLayersComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    public userSettings: UserSettings;

    constructor(
        public userPreferenceService: UserPreferenceService,
        public mapService: MapService,
        public userService: UserService,
        public qridLayersService: QridLayersService,
    ) {}

    ngOnInit() {
        this.userService.user.subscribe((user: User) => {
            console.log('Users/me from QRID:', user);
        });
    }
}
