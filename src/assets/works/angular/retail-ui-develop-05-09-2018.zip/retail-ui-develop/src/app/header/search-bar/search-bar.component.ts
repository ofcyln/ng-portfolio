import {
    Component,
    ElementRef,
    Input,
    OnChanges,
    OnInit,
    SimpleChanges,
    ViewChild,
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UserPreferenceService } from '../../auth/user/user-preference.service';
import { MapService } from '../../shared/map.service';
import { CityResponse, CityService } from '../../auth/data/city.service';
import { AlertService } from '../../alert/alert.service';
import { QridLayersService } from '../../map-filters/qrid-layers/qrid-layers.service';

export interface City extends CityResponse {
    selected: boolean;
}

@Component({
    selector: 'rdm-search-bar',
    templateUrl: './search-bar.component.html',
    styleUrls: ['./search-bar.component.scss'],
})
export class SearchBarComponent implements OnInit, OnChanges {
    public selectedCity: string;
    public selectedCityID: number;

    @Input() region: string;
    // @Output() cityChange = new EventEmitter<string>();
    // @Input() cityChange$: Observable<string>;

    public cities: City[];

    @ViewChild('regionSelectModalTemplate') regionSelectModalContent: ElementRef;
    // soldaki html de kullanılan isim,
    // diğer regionSelectModalContent sınıftaki ismi, bunları eşleştiriyoruz

    constructor(
        public translateService: TranslateService,
        public userPreferenceService: UserPreferenceService,
        public mapService: MapService,
        public cityService: CityService,
        public alertService: AlertService,
        public qridLayersService: QridLayersService,
    ) {}

    ngOnChanges(changes: SimpleChanges) {
        if (!changes['region'].isFirstChange()) {
            this.mapService.detailScreen = false;

            this.getCities();

            this.userPreferenceService.userSettings.cityInfo['AE'].selectedCity = 'Dubai';

            if (
                this.mapService.map.hasLayer(this.mapService.qridLayer) ||
                this.mapService.map.hasLayer(this.mapService.tileLayer)
            ) {
                this.mapService.map.removeLayer(this.mapService.tileLayer);
                this.mapService.map.removeLayer(this.mapService.qridLayer);
                this.mapService.map.closePopup();

                this.qridLayersService.setQridLayer(
                    this.qridLayersService.selectedItemIndex,
                    this.qridLayersService.selectedItemRehexID,
                );
            }
        }
    }

    ngOnInit() {
        this.translateService
            .stream('main.general.autocomplete.choose-city')
            .subscribe((translatedText) => (this.selectedCity = translatedText));

        this.getCities();
    }

    public getCities() {
        this.cityService.getCities().subscribe(
            (cityResponse: CityResponse[]) => {
                this.cities = cityResponse.map((item: CityResponse) => {
                    return <City>{
                        ...item,
                        selected: false,
                    };
                });
            },
            () => {
                this.alertService.error(
                    'An error occurred while cities of the region initialization!',
                );
            },
        );
    }

    public setSelectedCity(city: City) {
        this.mapService.detailScreen = false;

        this.selectedCity = city.City;

        this.selectedCityID = city.CityID;

        this.userPreferenceService.setCityInfo(city.CityID, this.selectedCity);

        this.mapService.setCityBounds(
            city.LowerLeft_Y,
            city.LowerLeft_X,
            city.UpperRight_Y,
            city.UpperRight_X,
        );

        if (
            this.mapService.map.hasLayer(this.mapService.qridLayer) ||
            this.mapService.map.hasLayer(this.mapService.tileLayer) ||
            this.userPreferenceService.userSettings.zoomLevel >= 13
        ) {
            this.mapService.map.removeLayer(this.mapService.tileLayer);
            this.mapService.map.removeLayer(this.mapService.qridLayer);
            this.mapService.map.closePopup();

            this.qridLayersService.cityID = this.selectedCityID;

            this.qridLayersService.setQridLayer(
                this.qridLayersService.selectedItemIndex,
                this.qridLayersService.selectedItemRehexID,
            );
        }
    }
}
