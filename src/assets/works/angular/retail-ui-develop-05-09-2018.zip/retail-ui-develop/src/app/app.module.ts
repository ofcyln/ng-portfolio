import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { HomeRoutingModule } from './home/home-routing.module';
import { MapModule } from './map/map.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AuthModule } from './auth/auth.module';
import { StorageService } from './shared/storage.service';
import { UserPreferenceService } from './auth/user/user-preference.service';
import { MapService } from './shared/map.service';
import { UserService } from './auth/user/user.service';
import { CityService } from './auth/data/city.service';
import { AlertModule } from './alert/alert.module';
import { RangeColorService } from './auth/data/range-color.service';
import { QridPopulationService } from './auth/data/qrid-population.service';
import { QridDetailsHeadService } from './auth/data/qrid-details-head.service';
import { QridTransportationService } from './auth/data/qrid-transportation.service';
import { QridPoiService } from './auth/data/qrid-poi.service';
import { QridLayersService } from './map-filters/qrid-layers/qrid-layers.service';
import { NgProgressInterceptor, NgProgressModule } from 'ngx-progressbar';
import { SocialService } from './map/qrid-details/tab-sections/social/social.service';
import { UserFilesService } from './auth/data/user-files.service';
import { MyDataService } from './map-filters/my-data/my-data.service';

@NgModule({
    declarations: [AppComponent, HomeComponent],
    imports: [
        BrowserModule,
        RouterModule,
        NgbModule.forRoot(),
        HomeRoutingModule,
        BrowserAnimationsModule,
        HttpClientModule,
        // the order of route defining modules is important
        AuthModule,
        NgProgressModule,
        AppRoutingModule,
        MapModule,
        AlertModule,
        TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactory,
                deps: [HttpClient],
            },
        }),
    ],
    providers: [
        {
            provide: HTTP_INTERCEPTORS,
            useClass: NgProgressInterceptor,
            multi: true,
        },
        StorageService,
        UserPreferenceService,
        MapService,
        UserService,
        CityService,
        QridLayersService,
        RangeColorService,
        QridPopulationService,
        QridTransportationService,
        QridPoiService,
        QridDetailsHeadService,
        SocialService,
        UserFilesService,
        MyDataService,
    ],
    bootstrap: [AppComponent],
})
export class AppModule {}

export function HttpLoaderFactory(http: HttpClient) {
    return new TranslateHttpLoader(http);
}
