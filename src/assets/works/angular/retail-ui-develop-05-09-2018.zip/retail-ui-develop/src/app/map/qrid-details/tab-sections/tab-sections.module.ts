import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AgeComponent } from './age/age.component';
import { EducationComponent } from './education/education.component';
import { IncomeComponent } from './income/income.component';
import { PoliticalComponent } from './political/political.component';
import { PopulationComponent } from './population/population.component';
import { TranslateModule } from '@ngx-translate/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TransportationComponent } from './transportation/transportation.component';
import { PoiComponent } from './poi/poi.component';
import { ChartModule, HIGHCHARTS_MODULES } from 'angular-highcharts';
import * as more from 'highcharts/highcharts-more.src';
import * as exporting from 'highcharts/modules/exporting.src';
import { SocialComponent } from './social/social.component';
import { Daterangepicker } from 'ng2-daterangepicker';
import { DpDatePickerModule } from 'ng2-date-picker';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { FormsModule } from '@angular/forms';
import { ScrollToModule } from '@nicky-lenaers/ngx-scroll-to';

@NgModule({
    imports: [
        CommonModule,
        NgbModule,
        FormsModule,
        TranslateModule,
        ChartModule,
        Daterangepicker,
        DpDatePickerModule,
        AngularMultiSelectModule,
        ScrollToModule.forRoot(),
    ],
    declarations: [
        AgeComponent,
        EducationComponent,
        IncomeComponent,
        PoliticalComponent,
        PopulationComponent,
        TransportationComponent,
        PoiComponent,
        SocialComponent,
    ],
    exports: [
        AgeComponent,
        EducationComponent,
        IncomeComponent,
        PoliticalComponent,
        PopulationComponent,
        TransportationComponent,
        PoiComponent,
        SocialComponent,
    ],
    providers: [
        {
            provide: HIGHCHARTS_MODULES,
            useFactory: () => [more, exporting],
        },
    ],
})
export class TabSectionsModule {}
