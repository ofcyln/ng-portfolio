import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MapService } from '../../../../shared/map.service';
import { TranslateService } from '@ngx-translate/core';
import { UserPreferenceService } from '../../../../auth/user/user-preference.service';
import { DatePickerDirective, IDatePickerDirectiveConfig } from 'ng2-date-picker';
import * as L from 'leaflet';
import { Moment } from 'moment';
import { SocialService } from './social.service';
import { NgbPanelChangeEvent } from '@ng-bootstrap/ng-bootstrap';
import { DropdownSettings } from 'angular2-multiselect-dropdown/multiselect.interface';
import {
    SocialMediaByCategoryResponse,
    SocialMediaSeriesByCategoryResponse,
    SocialMediaSeriesTotalResponse,
    SocialMediaSeriesVenueResponse,
    SocialMediaService,
    SocialMediaSummaryResponse,
    SocialMediaVenuesTotalResponse,
    VenueCheckinByDate,
} from '../../../../auth/data/social-media.service';
import { AlertService } from '../../../../alert/alert.service';
import { reverse, sortBy } from 'lodash-es';
import { Chart } from 'angular-highcharts';
import { LatLngLiteral, MarkerOptions } from 'leaflet';
import { ScrollToConfigOptions, ScrollToService } from '@nicky-lenaers/ngx-scroll-to';
import { PrimitiveModificationsService } from '../../../../auth/data/primitive-modifications.service';

export interface ListItem {
    id: number;
    itemName: string;
}

export interface TopCategory {
    name: string;
    data: number[];
    totalCheckinCount: number;
}

export interface SocialMediaSeriesByCategoryResponseInner {
    total_checkin_count: number;
    total_user_count: number;
    total_tip_count: number;
    total_visit_count: number;
    series: VenueCheckinByDate[];
}

export interface SocialMediaSeriesVenueResponseExtended extends SocialMediaSeriesVenueResponse {
    venueSelected: boolean;
}

@Component({
    selector: 'rdm-social',
    templateUrl: './social.component.html',
    styleUrls: ['./social.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class SocialComponent implements OnInit {
    @ViewChild('dateDirectivePickerStart') datePickerDirective: DatePickerDirective;

    public socialMediaResponse: SocialMediaSummaryResponse;
    public socialMediaByCategoryResponse: SocialMediaByCategoryResponse[];
    public socialMediaSeriesByCategoryResponse: SocialMediaSeriesByCategoryResponse;
    public socialMediaSeriesTotalResponse: SocialMediaSeriesTotalResponse[];
    public socialMediaVenuesTotalResponse: SocialMediaVenuesTotalResponse[];

    public socialMediaResponseWithDate: SocialMediaSummaryResponse;
    public socialMediaByCategoryResponseWithDate: SocialMediaByCategoryResponse[];
    public socialMediaSeriesByCategoryResponseWithDate: SocialMediaSeriesByCategoryResponse;
    public socialMediaSeriesTotalResponseWithDate: SocialMediaSeriesTotalResponse[];

    public categories: ListItem[] = [];
    public categoryModel: ListItem[] = [];
    public multiselectSettings: DropdownSettings;

    public startDateModel: Moment | string;
    public endDateModel: Moment | string;

    public datePickerConfig: IDatePickerDirectiveConfig;

    public totalCheckin: string;
    public visitCount: string;
    public footfall: string;

    public socialSummaryItems: SocialMediaByCategoryResponse[];
    public socialVenueItems: SocialMediaVenuesTotalResponse[];

    public commonChartOptions: any;
    public highchartsTotal: Chart;
    public highchartsTopCategories: Chart;
    public highchartsPlace: Chart;
    public highchartsTotalCheckins: number[];
    public lastYearsMonths: string[];

    public selectedPlace: boolean = false;
    public selectedVenueLocation: LatLngLiteral;
    public selectedVenueName: string;
    public venueSummary: SocialMediaSeriesVenueResponse[];
    public venueCheckins: number[];
    public venueVisitors: number[];

    public allTimeData: boolean = true;

    public multiselectCategories: string[];

    public venueSelected: boolean = false;

    protected readonly MAXIMUM_CATEGORIES_FOR_CHART = 5;
    protected readonly MAXIMUM_SELECTABLE_MONTH_RANGE = '201805';

    constructor(
        public mapService: MapService,
        public translateService: TranslateService,
        public userPreferencesService: UserPreferenceService,
        public socialService: SocialService,
        public alertService: AlertService,
        public socialMediaService: SocialMediaService,
        private scrollToService: ScrollToService,
        public primitiveModificationsService: PrimitiveModificationsService,
    ) {}

    ngOnInit() {
        this.datePickerConfig = {
            locale: this.userPreferencesService.userSettings.language.toLowerCase(),
            format: 'YYYYMM',
            monthFormat: 'YYYY-MM',
            drops: 'up',
            showGoToCurrent: false,
            max: this.MAXIMUM_SELECTABLE_MONTH_RANGE,
        };

        this.initSocialData();

        this.initMultiselectSettings();
    }

    public initSocialData(): void {
        this.startDateModel = undefined;
        this.endDateModel = undefined;

        this.socialService
            .getSocialMediaData(this.mapService.propertyRehexID)
            .subscribe((result) => {
                this.socialMediaResponse = <SocialMediaSummaryResponse>result[0];
                this.socialMediaByCategoryResponse = <SocialMediaByCategoryResponse[]>result[1];
                this.socialMediaSeriesByCategoryResponse = <SocialMediaSeriesByCategoryResponse>(
                    result[2]
                );
                this.socialMediaSeriesTotalResponse = <SocialMediaSeriesTotalResponse[]>result[3];
                this.socialMediaVenuesTotalResponse = <SocialMediaVenuesTotalResponse[]>result[4];

                this.categories = this.mapCategoryToMultiselect(
                    this.socialMediaSeriesByCategoryResponse,
                );

                this.visitCount = this.socialMediaResponse.unique_user.toLocaleString(
                    this.userPreferencesService.userSettings.language,
                );
                this.totalCheckin = this.socialMediaResponse.total_checkin.toLocaleString(
                    this.userPreferencesService.userSettings.language,
                );
                this.footfall = this.socialMediaResponse.visit_count.toLocaleString(
                    this.userPreferencesService.userSettings.language,
                );

                this.socialSummaryItems = this.sortCategoryResponse(
                    this.socialMediaByCategoryResponse,
                );

                this.socialVenueItems = this.sortVenuesTotalResponse(
                    this.socialMediaVenuesTotalResponse,
                );

                this.highchartsTotalCheckins = this.sortTotalSeriesCheckinsByDate(
                    this.socialMediaSeriesTotalResponse,
                );

                this.lastYearsMonths = this.primitiveModificationsService.semanticNamesOfMonths(
                    this.sortTotalVisitorsByDate(this.socialMediaSeriesTotalResponse),
                );

                if (this.highchartsTotalCheckins.length > 0) {
                    this.initCommonChart();
                    this.initTopCategoriesChart();
                }
            });
    }

    public initSocialDataUponDateRange(): void {
        this.socialService
            .getSocialMediaDataUponDate(
                this.mapService.propertyRehexID,
                this.startDateModel.toString(),
                this.endDateModel.toString(),
            )
            .subscribe((result) => {
                this.socialMediaResponseWithDate = <SocialMediaSummaryResponse>result[0];
                this.socialMediaByCategoryResponseWithDate = <SocialMediaByCategoryResponse[]>(
                    result[1]
                );
                this.socialMediaSeriesByCategoryResponseWithDate = <
                    SocialMediaSeriesByCategoryResponse
                >result[2];
                this.socialMediaSeriesTotalResponseWithDate = <SocialMediaSeriesTotalResponse[]>(
                    result[3]
                );

                this.categories = this.mapCategoryToMultiselect(
                    this.socialMediaSeriesByCategoryResponseWithDate,
                );

                this.visitCount = this.socialMediaResponseWithDate.unique_user.toLocaleString(
                    this.userPreferencesService.userSettings.language,
                );
                this.totalCheckin = this.socialMediaResponseWithDate.total_checkin.toLocaleString(
                    this.userPreferencesService.userSettings.language,
                );
                this.footfall = this.socialMediaResponseWithDate.visit_count.toLocaleString(
                    this.userPreferencesService.userSettings.language,
                );

                this.socialSummaryItems = this.sortCategoryResponse(
                    this.socialMediaByCategoryResponseWithDate,
                );
            });
    }

    public refreshData(): void {
        console.log(this.startDateModel);
        console.log(this.endDateModel);

        this.allTimeData = false;

        if (this.startDateModel >= this.endDateModel) {
            this.alertService.error('Start Date should be earlier than End Date!');
            this.startDateModel = undefined;
            this.endDateModel = undefined;
            return;
        } else if (this.startDateModel === undefined && this.endDateModel === undefined) {
            this.alertService.error('Please select date range to get new data set!');
            return;
        } else if (this.startDateModel === undefined && this.endDateModel !== undefined) {
            this.startDateModel = (Number(this.endDateModel) - 1).toString();
            this.initSocialDataUponDateRange();
        } else if (this.startDateModel !== undefined && this.endDateModel === undefined) {
            if (this.startDateModel > this.MAXIMUM_SELECTABLE_MONTH_RANGE) {
                this.startDateModel = (Number(this.MAXIMUM_SELECTABLE_MONTH_RANGE) - 1).toString();
                this.endDateModel = this.MAXIMUM_SELECTABLE_MONTH_RANGE;
                this.initSocialDataUponDateRange();
            }
            this.endDateModel = (Number(this.startDateModel) + 1).toString();
            this.initSocialDataUponDateRange();
        } else if (
            this.startDateModel !== undefined &&
            this.endDateModel !== undefined &&
            this.startDateModel !== this.endDateModel
        ) {
            this.initSocialDataUponDateRange();
        }
    }

    public sortCategoryResponse(
        response: SocialMediaByCategoryResponse[],
    ): SocialMediaByCategoryResponse[] {
        return reverse(sortBy(response, ['total_checkin', 'visit_count', 'unique_user'])).slice(
            0,
            this.MAXIMUM_CATEGORIES_FOR_CHART,
        );
    }

    public sortVenuesTotalResponse(
        response: SocialMediaVenuesTotalResponse[],
    ): SocialMediaVenuesTotalResponse[] {
        return reverse(sortBy(response, ['total_count', 'total_user', 'visit_count']));
    }

    public sortTotalSeriesCheckinsByDate(response: SocialMediaSeriesTotalResponse[]): number[] {
        return sortBy(
            response.map((item: SocialMediaSeriesTotalResponse) => {
                return item.total_checkin;
            }),
        ).slice(Math.max(response.length - 12, 1));
    }

    public sortTotalVisitorsByDate(response: SocialMediaSeriesTotalResponse[]): string[] {
        return sortBy(
            response.map((item: SocialMediaSeriesTotalResponse) => {
                return item.date;
            }),
        )
            .slice(Math.max(response.length - 12, 1))
            .map((date: string) => {
                return date.substr(date.length - 2);
            });
    }

    public sortPlaceCheckinsByDate(response: SocialMediaSeriesVenueResponse[]): number[] {
        return sortBy(
            response.map((item: SocialMediaSeriesVenueResponse) => {
                return item.checkinscountdiff;
            }),
        ).slice(Math.max(response.length - 12, 1));
    }

    public sortPlaceVisitorsByDate(response: SocialMediaSeriesVenueResponse[]): number[] {
        return sortBy(
            response.map((item: SocialMediaSeriesVenueResponse) => {
                return item.userscountdiff;
            }),
        ).slice(Math.max(response.length - 12, 1));
    }

    public setMarkerOptions(): MarkerOptions {
        return <MarkerOptions>{
            className: 'ricon-proje-pin-full',
        };
    }

    public showVenueOnMap(venueName: string, latitude: number, longitude: number): void {
        this.selectedVenueName = venueName;
        this.selectedVenueLocation = {
            lat: latitude,
            lng: longitude,
        };

        // this.venueSelected = !this.venueSelected;
        // console.log(this.venueSelected);

        if (this.socialService.venueMarker) {
            this.mapService.map.removeLayer(this.socialService.venueMarker);
        }

        this.mapService.map.setView(this.selectedVenueLocation, 17);

        setTimeout(() => {
            this.socialService.venueMarker = L.marker(this.selectedVenueLocation, {
                icon: L.divIcon({
                    // html: `<p>Hello!</p>`,
                    className: 'leaflet-marker-icon ricon-pin-full',
                }),
            })
                .addTo(this.mapService.map)
                .bindPopup(this.selectedVenueName, {
                    className: 'marker-popup',
                })
                .openPopup();

            this.socialService.venueMarker.on('mouseover', function() {
                this.openPopup();
            });

            this.socialService.venueMarker.on('mouseout', function() {
                this.closePopup();
            });
        }, 300);
    }

    public getVenueSummary(venueID: string, venueName: string): void {
        this.selectedPlace = false;

        this.socialMediaService.getSocialMediaSeriesVenue(venueID).subscribe(
            (response) => {
                this.venueSummary = response;
                this.venueCheckins = this.sortPlaceCheckinsByDate(this.venueSummary);
                this.venueVisitors = this.sortPlaceVisitorsByDate(this.venueSummary);
                this.selectedVenueName = venueName;

                this.initPlaceChart();

                this.selectedPlace = true;

                this.scrollToPlaceGraph();
            },
            (error) => {
                this.alertService.error(`Can't obtain venue summary! \nError: ${error}`);
            },
        );
    }

    public scrollToPlaceGraph(): void {
        const config: ScrollToConfigOptions = {
            target: 'place',
        };

        setTimeout(() => {
            this.scrollToService.scrollTo(config);
        }, 500);
    }

    public mapCategoryToMultiselect(response: SocialMediaSeriesByCategoryResponse): ListItem[] {
        return sortBy(Object.keys(response)).map((category: string, index: number) => {
            return {
                id: index,
                itemName: category,
            };
        });
    }

    public getTopCategoriesForChart(
        response: SocialMediaSeriesByCategoryResponse,
        amount: number,
    ): TopCategory[] {
        return sortBy(
            Object.keys(response).map((category: string) => {
                return <TopCategory>{
                    name: category,
                    data: response[category].series.map(
                        (venueCheckinByDate: VenueCheckinByDate) =>
                            venueCheckinByDate.checkin_count,
                    ),
                    totalCheckinCount: response[category].total_checkin_count,
                };
            }),
            ['total_checkin_count', 'total_user_count', 'total_visit_count'],
        ).slice(0, amount);
    }

    public beforeAccordionChange($event: NgbPanelChangeEvent): void {
        if ($event.panelId === 'accordionFilter' && $event.nextState === true) {
            console.log('Accordion opened by completing all conditions!');
        }
    }

    public onMultiselectSelectionChange() {
        // console.log('socialMediaSeriesByCategoryResponse', this.socialMediaSeriesByCategoryResponse);
        console.log('categoryModel', this.categoryModel);
        this.multiselectCategories = this.categoryModel.map(
            (category: ListItem): string => {
                return category.itemName;
            },
        );
        console.log('multiselect categories', this.multiselectCategories);
        // console.log('multiselect filtered socialMediaSeriesByCategoryResponse',
        //     this.multiselectCategories.map((categoyName: string): SocialMediaSeriesByCategoryResponseInner => {
        //     return this.socialMediaSeriesByCategoryResponse[categoyName];
        // }));

        // let rv = {};
        // for (let i = 0; i < arr.length; ++i) {
        //     rv[i] = arr[i];
        //     return rv;
        // }
    }

    public initCommonChart(): void {
        this.commonChartOptions = {
            chart: {
                type: 'area',
                style: {
                    fontSize: '11px',
                    fontFamily: 'Opensans, sans-serif',
                },
                width: 365,
                height: 300,
            },
            credits: {
                enabled: false,
            },
            exporting: {
                enabled: false,
            },
            title: {
                text: ' ',
            },
            xAxis: {
                title: {
                    text: this.translateService.instant(`main.project-details.month`),
                    style: {
                        fontSize: '11px',
                        fontFamily: 'Opensans, sans-serif',
                    },
                },
                categories: this.lastYearsMonths,
            },
            yAxis: {
                title: {
                    text: this.translateService.instant(`main.project-details.count`),
                    style: {
                        fontSize: '11px',
                        fontFamily: 'Opensans, sans-serif',
                    },
                },
                // labels: {
                //     formatter: () => {
                //         return this.value / 1000 + 'k';
                //     },
                // },
            },
            plotOptions: {
                series: {
                    allowPointSelect: true,
                },
            },
        };

        this.highchartsTotal = new Chart({
            ...this.commonChartOptions,
            colors: ['#57b45d'],
            series: [
                {
                    name: this.translateService.instant(
                        `main.project-details.total-checkin-small-caps`,
                    ),
                    data: this.highchartsTotalCheckins,
                },
            ],
        });

        // chart.ref$.subscribe(console.log);
    }

    public initTopCategoriesChart(): void {
        this.highchartsTopCategories = new Chart({
            ...this.commonChartOptions,
            colors: ['#f9a21a', '#0e3856', '#57b45d', '#d3d3d3', '#7b7a7a'],
            series: this.getTopCategoriesForChart(
                this.socialMediaSeriesByCategoryResponse,
                this.MAXIMUM_CATEGORIES_FOR_CHART,
            ),
        });
    }

    public initPlaceChart(): void {
        this.highchartsPlace = new Chart({
            ...this.commonChartOptions,
            colors: ['#57b45d', '#0e3856'],
            series: [
                {
                    name: this.translateService.instant(`main.project-details.user-count`),
                    data: this.venueVisitors,
                    visible: false,
                },
                {
                    name: this.translateService.instant(
                        `main.project-details.total-checkin-small-caps`,
                    ),
                    data: this.venueCheckins,
                },
            ],
        });
    }

    private initMultiselectSettings(): void {
        this.multiselectSettings = {
            text: this.translateService.instant(`main.project-details.categories`),
            selectAllText: this.translateService.instant(`main.project-details.select-all`),
            unSelectAllText: this.translateService.instant(`main.project-details.deselect-all`),
            searchPlaceholderText: this.translateService.instant(
                `main.project-details.search-categories`,
            ),
            noDataLabel: this.translateService.instant(`main.project-details.no-data`),
            singleSelection: false,
            enableSearchFilter: true,
            badgeShowLimit: 2,
            enableCheckAll: true,
            maxHeight: 150,
            classes: 'categories-multiselect',
            primaryKey: 'id',
            searchBy: [['itemName']],
            position: '',
        };
    }
}

// export const generalChartOptions = CLASSIN DISSINA
