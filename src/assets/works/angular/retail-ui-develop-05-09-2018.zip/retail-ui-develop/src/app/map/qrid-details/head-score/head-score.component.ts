import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MapService } from '../../../shared/map.service';

@Component({
    selector: 'rdm-head-score',
    templateUrl: './head-score.component.html',
    styleUrls: ['./head-score.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class HeadScoreComponent implements OnInit {
    constructor(public mapService: MapService) {}

    ngOnInit() {}
}
