import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResidenceComponent } from './residence/residence.component';
import { OfficeComponent } from './office/office.component';
import { MarketAnalysisComponent } from './market-analysis/market-analysis.component';
import { UrbanPlanningComponent } from './urban-planning/urban-planning.component';
import { TransactionComponent } from './transaction/transaction.component';
import { PoiComponent } from './poi/poi.component';
import { WorkspaceComponent } from './workspace/workspace.component';
import { LayerComponent } from './layer/layer.component';
import { ListingsComponent } from './listings/listings.component';
import { MapTypeComponent } from './map-type/map-type.component';
import { CustomizationComponent } from './customization/customization.component';
import { Daterangepicker } from 'ng2-daterangepicker';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule } from '@angular/forms';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { NouisliderModule } from 'ng2-nouislider';
import { HttpClientJsonpModule, HttpClientModule } from '@angular/common/http';
import { QridLayersComponent } from './qrid-layers/qrid-layers.component';
import { Ng2CompleterModule } from 'ng2-completer';
import { NgxUploaderModule } from 'ngx-uploader';
import { MyDataComponent } from './my-data/my-data.component';
import { RivalsDataComponent } from './rivals-data/rivals-data.component';

@NgModule({
    imports: [
        CommonModule,
        Daterangepicker,
        NgbModule,
        TranslateModule,
        FormsModule,
        Ng2CompleterModule,
        AngularMultiSelectModule,
        NouisliderModule,
        HttpClientModule,
        HttpClientJsonpModule,
        NgxUploaderModule,
    ],
    declarations: [
        ResidenceComponent,
        OfficeComponent,
        MarketAnalysisComponent,
        UrbanPlanningComponent,
        TransactionComponent,
        PoiComponent,
        WorkspaceComponent,
        LayerComponent,
        ListingsComponent,
        MapTypeComponent,
        CustomizationComponent,
        QridLayersComponent,
        MyDataComponent,
        RivalsDataComponent,
    ],
    exports: [
        ResidenceComponent,
        OfficeComponent,
        MarketAnalysisComponent,
        UrbanPlanningComponent,
        TransactionComponent,
        PoiComponent,
        WorkspaceComponent,
        LayerComponent,
        ListingsComponent,
        MapTypeComponent,
        CustomizationComponent,
        QridLayersComponent,
        NgxUploaderModule,
    ],
})
export class MapFiltersModule {}
