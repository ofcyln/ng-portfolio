import { TestBed, inject } from '@angular/core/testing';

import { PrimitiveModificationsService } from './primitive-modifications.service';

describe('PrimitiveModificationsService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PrimitiveModificationsService],
        });
    });

    it('should be created', inject(
        [PrimitiveModificationsService],
        (service: PrimitiveModificationsService) => {
            expect(service).toBeTruthy();
        },
    ));
});
