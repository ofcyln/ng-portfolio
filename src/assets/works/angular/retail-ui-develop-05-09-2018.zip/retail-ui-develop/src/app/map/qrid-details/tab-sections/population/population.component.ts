import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MapService } from '../../../../shared/map.service';
import { TranslateService } from '@ngx-translate/core';
import { UserPreferenceService } from '../../../../auth/user/user-preference.service';

@Component({
    selector: 'rdm-population',
    templateUrl: './population.component.html',
    styleUrls: ['./population.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class PopulationComponent implements OnInit {
    public generation1535: number;
    public ratioOfYoungGeneration: number;

    constructor(
        public mapService: MapService,
        public translateService: TranslateService,
        public userPreferencesService: UserPreferenceService,
    ) {}

    ngOnInit() {}

    public setYoungPopulationCalculation() {
        this.generation1535 =
            this.mapService.populationDemography.Age20_24 +
            this.mapService.populationDemography.Age15_19 +
            this.mapService.populationDemography.Age25_29 +
            this.mapService.populationDemography.Age30_34;

        this.ratioOfYoungGeneration =
            this.generation1535 / this.mapService.populationDemography.Total;

        return (this.ratioOfYoungGeneration * 100).toFixed();
    }
}
