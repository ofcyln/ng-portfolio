import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RivalsDataComponent } from './rivals-data.component';

describe('RivalsDataComponent', () => {
    let component: RivalsDataComponent;
    let fixture: ComponentFixture<RivalsDataComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [RivalsDataComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(RivalsDataComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
