import { Component, OnInit } from '@angular/core';
import { MenuElement, SidebarService } from './sidebar.service';
import { Router } from '@angular/router';

@Component({
    selector: 'rdm-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss'],
    providers: [SidebarService],
})
export class SidebarComponent implements OnInit {
    public menuElements: MenuElement[] = [];
    public clearActive: boolean;

    constructor(public sidebarService: SidebarService, public router: Router) {}

    public ngOnInit() {
        this.menuElements = this.sidebarService.getMenuElements();
    }

    public navigateTo(menuElement: MenuElement) {
        const homePath = '/home';

        if (this.router.isActive(`${homePath}/${menuElement.route}`, true)) {
            this.router.navigate([homePath]);
        }
    }
}
