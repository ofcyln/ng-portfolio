import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MapService } from '../../../../shared/map.service';
import { TranslateService } from '@ngx-translate/core';
import { UserPreferenceService } from '../../../../auth/user/user-preference.service';
import { Chart } from 'angular-highcharts';

@Component({
    selector: 'rdm-age',
    templateUrl: './age.component.html',
    styleUrls: ['./age.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class AgeComponent implements OnInit {
    public ageChart: Chart;

    public ageText: string;

    constructor(
        public mapService: MapService,
        public translate: TranslateService,
        public translateService: TranslateService,
        public userPreferencesService: UserPreferenceService,
    ) {}

    ngOnInit() {
        this.translateService
            .stream('main.project-details.age')
            .subscribe((translatedText) => (this.ageText = translatedText));

        this.initChart();
    }

    public initChart() {
        this.ageChart = new Chart({
            chart: {
                type: 'column',
                style: {
                    fontSize: '11px',
                    fontFamily: 'Opensans, sans-serif',
                },
                width: 365,
                height: 182,
            },
            colors: ['#0e3856'],
            title: {
                text: ' ',
            },
            xAxis: {
                type: 'category',
                labels: {
                    rotation: -45,
                    style: {
                        fontSize: '11px',
                        fontFamily: 'Opensans, sans-serif',
                    },
                },
            },
            yAxis: {
                min: 0,
                title: {
                    text: '',
                },
                labels: {
                    style: {
                        fontSize: '11px',
                        fontFamily: 'Opensans, sans-serif',
                    },
                },
            },
            legend: {
                enabled: false,
            },
            tooltip: {
                pointFormat: `Population: <b>{point.y:.1f}</b>`,
                style: {
                    fontSize: '11px',
                    fontFamily: 'Verdana, sans-serif',
                },
            },
            series: [
                {
                    name: 'Population',
                    data: [
                        [
                            this.ageText + ' 0-4',
                            Number(this.mapService.populationDemography.Age0_4.toFixed()),
                        ],
                        [
                            this.ageText + ' 5-18',
                            Number(
                                (
                                    this.mapService.populationDemography.Age15_19 +
                                    this.mapService.populationDemography.Age10_14 +
                                    this.mapService.populationDemography.Age5_9
                                ).toFixed(),
                            ),
                        ],
                        [
                            this.ageText + ' 19-34',
                            Number(
                                (
                                    this.mapService.populationDemography.Age20_24 +
                                    this.mapService.populationDemography.Age25_29 +
                                    this.mapService.populationDemography.Age30_34
                                ).toFixed(),
                            ),
                        ],
                        [
                            this.ageText + ' 35-55',
                            Number(
                                (
                                    this.mapService.populationDemography.Age35_39 +
                                    this.mapService.populationDemography.Age40_44 +
                                    this.mapService.populationDemography.Age45_49 +
                                    this.mapService.populationDemography.Age50_54
                                ).toFixed(),
                            ),
                        ],
                        [
                            this.ageText + ' 56-65',
                            Number(
                                (
                                    this.mapService.populationDemography.Age55_59 +
                                    this.mapService.populationDemography.Age60_64
                                ).toFixed(),
                            ),
                        ],
                        [
                            this.ageText + ' 65+',
                            Number(this.mapService.populationDemography.Age65_.toFixed()),
                        ],
                    ],
                },
            ],
        });

        // totalChart.ref$.subscribe(console.log);
    }
}
