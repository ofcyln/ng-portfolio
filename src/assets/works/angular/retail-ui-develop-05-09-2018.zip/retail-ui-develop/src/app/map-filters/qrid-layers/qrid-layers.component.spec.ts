import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QridLayersComponent } from './qrid-layers.component';

describe('QridLayersComponent', () => {
    let component: QridLayersComponent;
    let fixture: ComponentFixture<QridLayersComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [QridLayersComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(QridLayersComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
