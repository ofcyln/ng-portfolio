import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { UserPreferenceService } from '../user/user-preference.service';
import { Observable } from 'rxjs';

export interface CityResponse {
    CNTYCODE: string;
    Centroid_X: number;
    Centroid_Y: number;
    City: string;
    CityID: number;
    CountryID: number;
    LowerLeft_X: number;
    LowerLeft_Y: number;
    UpperRight_X: number;
    UpperRight_Y: number;
}

@Injectable()
export class CityService {
    constructor(public http: HttpClient, public userPreferenceService: UserPreferenceService) {}

    public getCities(): Observable<CityResponse[]> {
        return this.http.get<CityResponse[]>(
            `${environment.contentAPIUrl}/api/v1/city/${
                this.userPreferenceService.userSettings.countryCode
            }`,
        );
    }
}
