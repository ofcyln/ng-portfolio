import { Injectable } from '@angular/core';
import { UserService } from '../../auth/user/user.service';
import { UserPreferenceService, UserSettings } from '../../auth/user/user-preference.service';
import { MapService } from '../../shared/map.service';

interface DeclaredLayer {
    id: string;
    title: string;
    translateText: string;
    defaultTranslationText: string;
    icon: string;
    rehexID: string;
    selected: boolean;
}

@Injectable()
export class QridLayersService {
    public layers: Array<DeclaredLayer> = [
        {
            id: 'qrid',
            title: 'QRID',
            translateText: 'qrid',
            defaultTranslationText: 'QRID',
            icon: 'ricon-qrid',
            rehexID: 'Rehex',
            selected: false,
        },
        {
            id: 'socialMedia',
            title: 'Sosyal Medya',
            translateText: 'social-media',
            defaultTranslationText: 'Social Media',
            icon: 'ricon-social',
            rehexID: 'Social',
            selected: false,
        },
        {
            id: 'population',
            title: 'Nüfus',
            translateText: 'population',
            defaultTranslationText: 'Population',
            icon: 'ricon-population',
            rehexID: 'Population',
            selected: false,
        },
        {
            id: 'transport',
            title: 'Ulaşım',
            translateText: 'transportation',
            defaultTranslationText: 'Transportation',
            icon: 'ricon-transportation',
            rehexID: 'Transport',
            selected: false,
        },
        {
            id: 'poi',
            title: 'POI',
            translateText: 'poi',
            defaultTranslationText: 'POI',
            icon: 'ricon-poi',
            rehexID: 'Poi',
            selected: false,
        },
        // {
        //     id: 'rent',
        //     title: 'Kira Fiyatları',
        //     translateText: 'rental-price',
        //     defaultTranslationText: 'Rent',
        //     icon: 'ricon-rent',
        //     rehexID: 'Rent',
        //     selected: false,
        // },
    ];

    public userSettings: UserSettings;

    public selectedItemState: boolean;
    public selectedItemIndex: number;
    public selectedItemRehexID: string;

    public cityID: number;

    constructor(
        public userPreferenceService: UserPreferenceService,
        public mapService: MapService,
        public userService: UserService,
    ) {}

    public setSelectedLayerState(index: number) {
        this.setCheckboxesPassive(index);

        this.layers[index].selected = !this.layers[index].selected;
    }

    public setCheckboxesPassive(selectedItemIndex: number) {
        this.layers
            .filter((item, index) => {
                return selectedItemIndex !== index;
            })
            .map((item) => {
                item.selected = false;
                return item;
            });
    }

    public setQridLayer(index: number, rehexID: string) {
        this.cityID = this.userPreferenceService.userSettings.cityInfo[
            this.userPreferenceService.userSettings.countryCode
        ].cityID;

        // this.mapService.selectedCityState = this.layers[index].selected;
        //
        // console.log(this.mapService.selectedCityState);

        this.selectedItemState = this.layers[index].selected;
        this.selectedItemIndex = index;
        this.selectedItemRehexID = this.layers[index].rehexID;

        console.log('selected qrid layer state:', this.layers[index].selected);

        if (this.layers[index].selected === true) {
            if (
                this.mapService.map.hasLayer(this.mapService.qridLayer) ||
                this.mapService.map.hasLayer(this.mapService.tileLayer)
            ) {
                console.log('removing previous selection of QRID Layer!');
                this.mapService.map.removeLayer(this.mapService.qridLayer);
                this.mapService.map.removeLayer(this.mapService.tileLayer);
                this.mapService.map.closePopup();
                this.mapService.detailScreen = false;
            }
            console.log('initializing new selected QRID Layer!');

            this.mapService.addQridLayer(this.cityID, rehexID);
        } else {
            console.log('removing selected QRID Layer!');

            this.mapService.map.removeLayer(this.mapService.qridLayer);
            this.mapService.map.removeLayer(this.mapService.tileLayer);
            this.mapService.map.closePopup();
            this.mapService.detailScreen = false;
        }

        this.mapService.map.on('zoomend', () => {
            if (
                this.layers[index].selected === true &&
                this.userPreferenceService.userSettings.zoomLevel >= 13
            ) {
                this.mapService.map.removeLayer(this.mapService.tileLayer);
                this.mapService.map.closePopup();
                this.mapService.map.addLayer(this.mapService.qridLayer);
                this.mapService.map.on('click', this.mapService.clearHighlight);
            } else if (
                this.layers[index].selected === true &&
                this.userPreferenceService.userSettings.zoomLevel < 13
            ) {
                this.mapService.map.closePopup();
                this.mapService.map.removeLayer(this.mapService.qridLayer);
                this.mapService.map.addLayer(this.mapService.tileLayer);
            } else if (
                this.layers[index].selected === false &&
                (this.mapService.map.hasLayer(this.mapService.qridLayer) ||
                    this.mapService.map.hasLayer(this.mapService.tileLayer))
            ) {
                this.mapService.map.closePopup();
                this.mapService.map.removeLayer(this.mapService.qridLayer);
                this.mapService.map.removeLayer(this.mapService.tileLayer);
            }
        });
    }
}
