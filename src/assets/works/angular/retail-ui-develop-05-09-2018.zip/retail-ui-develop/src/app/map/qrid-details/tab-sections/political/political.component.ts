import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'rdm-political',
    templateUrl: './political.component.html',
    styleUrls: ['./political.component.scss'],
})
export class PoliticalComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
