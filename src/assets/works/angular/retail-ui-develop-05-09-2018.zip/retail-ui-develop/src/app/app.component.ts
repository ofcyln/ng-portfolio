import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UserPreferenceService } from './auth/user/user-preference.service';

@Component({
    moduleId: module.id,
    selector: 'rdm-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css'],
})
export class AppComponent {
    public title = 'ReidiMap';

    constructor(
        public translate: TranslateService,
        public userPreferenceService: UserPreferenceService,
    ) {
        translate.addLangs(['en', 'tr']);
        translate.setDefaultLang(userPreferenceService.userSettings.language);
    }
}
