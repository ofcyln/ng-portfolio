import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'rdm-similar-qrids',
    templateUrl: './similar-qrids.component.html',
    styleUrls: ['./similar-qrids.component.scss'],
})
export class SimilarQridsComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
