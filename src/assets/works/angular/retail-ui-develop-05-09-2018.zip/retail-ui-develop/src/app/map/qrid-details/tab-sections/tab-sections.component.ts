import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { UserPreferenceService } from '../../../auth/user/user-preference.service';

@Component({
    selector: 'rdm-tab-sections',
    templateUrl: './tab-sections.component.html',
    styleUrls: ['./tab-sections.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class TabSectionsComponent implements OnInit {
    constructor(public userPreferencesService: UserPreferenceService) {}

    ngOnInit() {}
}
