import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../auth/authentication.service';

@Component({
    selector: 'rdm-logout-button',
    templateUrl: './logout-button.component.html',
    styleUrls: ['./logout-button.component.scss'],
})
export class LogoutButtonComponent implements OnInit {
    constructor(public router: Router, public authenticationService: AuthenticationService) {}

    ngOnInit() {}

    public navigateToLoginPage() {
        this.router.navigate(['/login']);
    }
}
