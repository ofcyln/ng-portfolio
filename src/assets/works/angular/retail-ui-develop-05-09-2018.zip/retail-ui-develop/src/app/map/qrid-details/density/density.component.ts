import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MapService } from '../../../shared/map.service';

@Component({
    selector: 'rdm-density',
    templateUrl: './density.component.html',
    styleUrls: ['./density.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class DensityComponent implements OnInit {
    constructor(public mapService: MapService) {}

    ngOnInit() {
        // this.mapService.initMap();
    }
}
