import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MapComponent } from './map.component';
import { MapFiltersModule } from '../map-filters/map-filters.module';
import { AlertModule } from '../alert/alert.module';
import { QridDetailsModule } from './qrid-details/qrid-details.module';
import { QridDetailsComponent } from './qrid-details/qrid-details.component';

@NgModule({
    imports: [CommonModule, MapFiltersModule, AlertModule, QridDetailsModule],
    declarations: [MapComponent, QridDetailsComponent],
    entryComponents: [MapComponent],
    exports: [MapComponent, MapFiltersModule, QridDetailsModule],
})
export class MapModule {}
