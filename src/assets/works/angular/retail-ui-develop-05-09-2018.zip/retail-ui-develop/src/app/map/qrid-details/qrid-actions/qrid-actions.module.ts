import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SimilarQridsComponent } from './similar-qrids/similar-qrids.component';
import { ComparisonComponent } from './comparison/comparison.component';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
    imports: [CommonModule, TranslateModule],
    declarations: [SimilarQridsComponent, ComparisonComponent],
    exports: [SimilarQridsComponent, ComparisonComponent],
})
export class QridActionsModule {}
