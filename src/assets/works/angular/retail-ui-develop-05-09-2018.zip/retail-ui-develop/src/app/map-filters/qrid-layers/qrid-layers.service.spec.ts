import { TestBed, inject } from '@angular/core/testing';

import { QridLayersService } from './qrid-layers.service';

describe('QridLayersService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [QridLayersService],
        });
    });

    it('should be created', inject([QridLayersService], (service: QridLayersService) => {
        expect(service).toBeTruthy();
    }));
});
