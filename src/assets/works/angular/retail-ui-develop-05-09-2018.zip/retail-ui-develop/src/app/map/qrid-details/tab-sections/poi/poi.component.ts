import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { MapService } from '../../../../shared/map.service';
import { QridPoiResponse } from '../../../../auth/data/qrid-poi.service';

@Component({
    selector: 'rdm-poi',
    templateUrl: './poi.component.html',
    styleUrls: ['./poi.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class PoiComponent implements OnInit {
    public poiItems: Array<QridPoiResponse> = this.mapService.qridPoiSummary;

    constructor(public mapService: MapService, public translateService: TranslateService) {}

    ngOnInit() {}
}
