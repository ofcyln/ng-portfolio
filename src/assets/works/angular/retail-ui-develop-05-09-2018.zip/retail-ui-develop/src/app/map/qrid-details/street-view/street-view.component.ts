import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'rdm-street-view',
    templateUrl: './street-view.component.html',
    styleUrls: ['./street-view.component.scss'],
})
export class StreetViewComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
