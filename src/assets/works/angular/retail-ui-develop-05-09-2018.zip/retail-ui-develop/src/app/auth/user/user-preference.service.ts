import { Injectable } from '@angular/core';
import { StorageService } from '../../shared/storage.service';
import { LatLngLiteral } from 'leaflet';

// import * as L from 'leaflet';

export interface CityInfo {
    cityID: number;
    selectedCity: string;
}

export interface UserSettings {
    currency: string; // 'TRL' | 'USD' unutma!
    measurement: string;
    countryId: number;
    countryCode: string;
    locale: string;
    language: string;
    activeMap: string;
    zoomLevel: number;
    cityInfo: {
        [key: string]: CityInfo;
    };
    mapCenter: {
        [key: string]: LatLngLiteral;
    };
}

@Injectable()
export class UserPreferenceService {
    private _userSettings: UserSettings;
    private readonly defaultUserSettings: UserSettings = {
        currency: 'TRL',
        measurement: 'INT',
        countryId: 231,
        countryCode: 'TR',
        locale: 'tr_TR',
        language: 'en',
        activeMap: 'roadmap',
        zoomLevel: 12,
        cityInfo: {
            AE: {
                cityID: 4460,
                selectedCity: 'Dubai',
            },
            TR: {
                cityID: 3969,
                selectedCity: 'İstanbul',
            },
        },
        mapCenter: {
            AE: {
                lat: 25.053961628714603,
                lng: 55.10295733809472,
            },
            TR: {
                lat: 41.03513764127896,
                lng: 29.027089923620228,
            },
        },
    };

    constructor(public storageService: StorageService) {}

    public get userSettings(): UserSettings {
        const userSettings = this.getUserSettings();

        if (this._userSettings) {
            return this._userSettings;
        } else if (userSettings) {
            return userSettings;
        } else if (userSettings.mapCenter['TR'].lat === 25.053961628714603) {
            return this.defaultUserSettings;
        } else {
            return this.defaultUserSettings;
        }
    }

    // TODO: "this.userPreferenceService.userSettings ="'de "public set userSettings..."
    // cagrilir, set te donus tipi yoktur, obje degildir
    // chain yaptiginda cagirma noktasi gecilir cunku objelerde yapilir

    public set userSettings(settings: UserSettings) {
        this.setUserSettings(settings);
    }

    public setCurrency(currency: string) {
        this.userSettings = {
            ...this.userSettings,
            currency,
        };
    }

    public setMeasurement(measurement: string) {
        this.userSettings = {
            ...this.userSettings,
            measurement,
        };
    }

    public setCountryCode(countryCode: string) {
        this.userSettings = {
            ...this.userSettings,
            countryCode,
        };
    }

    public setLanguage(language: string) {
        this.userSettings = {
            ...this.userSettings,
            language,
        };
    }

    public setCityInfo(cityID: number, selectedCity: string) {
        this.userSettings = {
            ...this.userSettings,
            cityInfo: {
                ...this.userSettings.cityInfo,
                [this.userSettings.countryCode]: {
                    cityID: cityID,
                    selectedCity: selectedCity,
                },
            },
        };
    }

    private setUserSettings(userSettings: UserSettings): void {
        this.storageService.setObject('userSettings', userSettings);
        this._userSettings = userSettings;
    }

    private getUserSettings(): UserSettings {
        return <UserSettings>this.storageService.getObject('userSettings');
        // cast etme <UserSettings>, sagdaki gelen seye bu type i atiyorsun
    }
}
