import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QridDetailsComponent } from './qrid-details.component';

describe('QridDetailsComponent', () => {
    let component: QridDetailsComponent;
    let fixture: ComponentFixture<QridDetailsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [QridDetailsComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(QridDetailsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
