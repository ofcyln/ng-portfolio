import { Injectable } from '@angular/core';
import { MapService } from '../../../../shared/map.service';
import { UserPreferenceService } from '../../../../auth/user/user-preference.service';
import { SocialMediaService } from '../../../../auth/data/social-media.service';
import { throwError, zip } from 'rxjs';
import { AlertService } from '../../../../alert/alert.service';
import { catchError } from 'rxjs/operators';
import * as L from 'leaflet';

@Injectable({
    providedIn: 'root',
})
export class SocialService {
    public venueMarker: L.Marker;

    constructor(
        public mapService: MapService,
        public alertService: AlertService,
        public userPreferencesService: UserPreferenceService,
        public socialMediaService: SocialMediaService,
    ) {}

    public getSocialMediaData(hexagonID: number) {
        return zip(
            this.socialMediaService.getSocialMediaSummary(hexagonID),
            this.socialMediaService.getSocialMediaByCategory(hexagonID),
            this.socialMediaService.getSocialMediaSeriesByCategory(hexagonID),
            this.socialMediaService.getSocialMediaSeriesTotal(hexagonID),
            this.socialMediaService.getSocialMediaVenuesTotal(hexagonID),
        ).pipe(
            catchError((error) => {
                this.alertService.error(
                    `Error while getting Social Media Category & Series data from server: ${
                        error.message
                    }!`,
                );

                return throwError(error);
            }),
        );
    }

    public getSocialMediaDataUponDate(hexagonID: number, startDate: string, endDate: string) {
        return zip(
            this.socialMediaService.getSocialMediaSummaryRange(hexagonID, startDate, endDate),
            this.socialMediaService.getSocialMediaByCategoryRange(hexagonID, startDate, endDate),
            this.socialMediaService.getSocialMediaSeriesByCategoryRange(
                hexagonID,
                startDate,
                endDate,
            ),
            this.socialMediaService.getSocialMediaSeriesTotalRange(hexagonID, startDate, endDate),
        ).pipe(
            catchError((error) => {
                this.alertService.error(
                    `Error while getting Social Media Category & Series data with date range from server: ${
                        error.message
                    }!`,
                );

                return throwError(error);
            }),
        );
    }
}
