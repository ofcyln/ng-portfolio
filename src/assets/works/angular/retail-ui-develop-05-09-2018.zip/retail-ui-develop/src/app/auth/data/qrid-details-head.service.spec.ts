import { TestBed, inject } from '@angular/core/testing';

import { QridDetailsHeadService } from './qrid-details-head.service';

describe('QridDetailsHeadService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [QridDetailsHeadService],
        });
    });

    it('should be created', inject([QridDetailsHeadService], (service: QridDetailsHeadService) => {
        expect(service).toBeTruthy();
    }));
});
