import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'rdm-comparison',
    templateUrl: './comparison.component.html',
    styleUrls: ['./comparison.component.scss'],
})
export class ComparisonComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
