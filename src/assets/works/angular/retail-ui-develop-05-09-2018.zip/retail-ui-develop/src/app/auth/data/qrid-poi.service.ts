import { Injectable } from '@angular/core';
import { UserPreferenceService } from '../user/user-preference.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface QridPoiResponse {
    SubTypeID: number;
    Category: string;
    Poi_Distance: number;
    Poi_ID: number;
    Poi_name: string;
    Poi_count: number;
}

@Injectable()
export class QridPoiService {
    constructor(public http: HttpClient, public userPreferenceService: UserPreferenceService) {}

    public getQridPoi(rehexID: number): Observable<QridPoiResponse[]> {
        return this.http.get<QridPoiResponse[]>(
            `${environment.contentAPIUrl}/api/v1/poi/summary/${
                this.userPreferenceService.userSettings.countryCode
            }/${rehexID}`,
        );
    }
}
