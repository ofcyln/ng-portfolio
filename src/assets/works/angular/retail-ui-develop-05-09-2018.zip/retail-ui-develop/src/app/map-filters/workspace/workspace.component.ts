import { Component, HostBinding, OnInit } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';

@Component({
    selector: 'rdm-workspace',
    templateUrl: './workspace.component.html',
    styleUrls: ['./workspace.component.scss'],
    animations: [slideInLeftAnimation],
})
export class WorkspaceComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    constructor() {}

    ngOnInit() {}
}
