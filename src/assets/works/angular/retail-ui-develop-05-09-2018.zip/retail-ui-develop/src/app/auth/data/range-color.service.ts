import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { UserPreferenceService } from '../user/user-preference.service';
import { Observable } from 'rxjs';

export interface RangeColorResponse {
    [key: string]: {
        [key: string]: {
            ClassBreaks: Array<number>;
            ColorPalette: Array<string>;
        };
    };
}

@Injectable()
export class RangeColorService {
    constructor(public http: HttpClient, public userPreferenceService: UserPreferenceService) {}

    public getRangeColors(
        cityID: number,
        rehexID: string,
        colorSchema: string,
    ): Observable<RangeColorResponse> {
        return this.http.get<RangeColorResponse>(
            `${environment.contentAPIUrl}/api/v1/styles/colorranges/${
                this.userPreferenceService.userSettings.countryCode
            }/${cityID}/${rehexID}?color_scheme=${colorSchema}`,
        );
    }
}
