import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UrbanPlanningComponent } from './urban-planning.component';

describe('UrbanPlanningComponent', () => {
    let component: UrbanPlanningComponent;
    let fixture: ComponentFixture<UrbanPlanningComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [UrbanPlanningComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(UrbanPlanningComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
