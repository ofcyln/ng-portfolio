import { Injectable } from '@angular/core';
import { UserPreferenceService } from '../user/user-preference.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface SocialMediaSummaryResponse {
    total_checkin: number;
    unique_user: number;
    visit_count: number;
}

export interface SocialMediaByCategoryResponse {
    category: string;
    total_checkin: number;
    unique_user: number;
    visit_count: number;
}

export interface SocialMediaSeriesByCategoryResponse {
    [category: string]: {
        total_checkin_count: number;
        total_user_count: number;
        total_tip_count: number;
        total_visit_count: number;
        series: VenueCheckinByDate[];
    };
}

export interface VenueCheckinByDate {
    date: string;
    checkin_count: number;
    user_count: number;
    tip_count: number;
    visit_count: number;
}

export interface SocialMediaSeriesTotalResponse {
    date: string;
    category: string;
    total_checkin: number;
    unique_user: number;
    visit_count: number;
}

export interface SocialMediaVenuesTotalResponse {
    venueid: string;
    venuename: string;
    rating: number;
    venuereview: string;
    Loyalty: number;
    total_count: number;
    total_user: number;
    Kategori: string;
    Category: string;
    visit_count: number;
    total_count_change_count: number;
    total_count_change_per: number;
    total_user_change_count: number;
    total_user_change_per: number;
    visit_count_change_count: number;
    visit_count_change_per: number;
    latitude: number;
    longitude: number;
    price: number;
}
export interface SocialMediaSeriesVenueResponse {
    created_on: string;
    rating: number;
    checkinscount: number;
    checkinscountdiff: number;
    checkinscountdiffp: number;
    userscount: number;
    userscountdiff: number;
    userscountdiffp: number;
    tipcount: number;
    tipcountdiff: number;
    tipcountdiffp: number;
    visitscount: number;
    visitscountdiff: number;
    visitscountdiffp: number;
}

@Injectable({
    providedIn: 'root',
})
export class SocialMediaService {
    constructor(public http: HttpClient, public userPreferenceService: UserPreferenceService) {}

    public getSocialMediaSummary(hexagonID: number): Observable<SocialMediaSummaryResponse> {
        return this.http.get<SocialMediaSummaryResponse>(
            `${environment.contentAPIUrl}/api/v1/socialmedia/summary/${hexagonID}`,
        );
    }

    public getSocialMediaSummaryRange(
        hexagonID: number,
        startDate: string,
        endDate: string,
    ): Observable<SocialMediaSummaryResponse> {
        return this.http.get<SocialMediaSummaryResponse>(
            `${
                environment.contentAPIUrl
            }/api/v1/socialmedia/summary/${hexagonID}/${startDate}/${endDate}`,
        );
    }

    public getSocialMediaByCategory(
        hexagonID: number,
    ): Observable<SocialMediaByCategoryResponse[]> {
        return this.http.get<SocialMediaByCategoryResponse[]>(
            `${environment.contentAPIUrl}/api/v1/socialmedia/bycategory/${hexagonID}`,
        );
    }

    public getSocialMediaByCategoryRange(
        hexagonID: number,
        startDate: string,
        endDate: string,
    ): Observable<SocialMediaByCategoryResponse[]> {
        return this.http.get<SocialMediaByCategoryResponse[]>(
            `${
                environment.contentAPIUrl
            }/api/v1/socialmedia/bycategory/${hexagonID}/${startDate}/${endDate}`,
        );
    }

    public getSocialMediaSeriesByCategory(
        hexagonID: number,
    ): Observable<SocialMediaSeriesByCategoryResponse> {
        return this.http.get<SocialMediaSeriesByCategoryResponse>(
            `${environment.contentAPIUrl}/api/v1/socialmedia/series/bycategory/${hexagonID}`,
        );
    }

    public getSocialMediaSeriesByCategoryRange(
        hexagonID: number,
        startDate: string,
        endDate: string,
    ): Observable<SocialMediaSeriesByCategoryResponse> {
        return this.http.get<SocialMediaSeriesByCategoryResponse>(
            `${
                environment.contentAPIUrl
            }/api/v1/socialmedia/series/bycategory/${hexagonID}/${startDate}/${endDate}`,
        );
    }

    public getSocialMediaSeriesTotal(
        hexagonID: number,
    ): Observable<SocialMediaSeriesTotalResponse[]> {
        return this.http.get<SocialMediaSeriesTotalResponse[]>(
            `${environment.contentAPIUrl}/api/v1/socialmedia/series/total/${hexagonID}`,
        );
    }

    public getSocialMediaSeriesTotalRange(
        hexagonID: number,
        startDate: string,
        endDate: string,
    ): Observable<SocialMediaSeriesTotalResponse[]> {
        return this.http.get<SocialMediaSeriesTotalResponse[]>(
            `${
                environment.contentAPIUrl
            }/api/v1/socialmedia/series/total/${hexagonID}/${startDate}/${endDate}`,
        );
    }

    public getSocialMediaVenuesTotal(
        hexagonID: number,
    ): Observable<SocialMediaVenuesTotalResponse[]> {
        return this.http.get<SocialMediaVenuesTotalResponse[]>(
            `${environment.contentAPIUrl}/api/v1/socialmedia/venues/total/${hexagonID}`,
        );
    }

    public getSocialMediaSeriesVenue(
        venueID: string,
    ): Observable<SocialMediaSeriesVenueResponse[]> {
        return this.http.get<SocialMediaSeriesVenueResponse[]>(
            `${environment.contentAPIUrl}/api/v1/socialmedia/series/venue/${venueID}`,
        );
    }
}
