import { Injectable } from '@angular/core';
import { UserPreferenceService } from '../user/user-preference.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface QridPopulationResponse {
    Age0_4: number;
    Age10_14: number;
    Age15_19: number;
    Age20_24: number;
    Age25_29: number;
    Age30_34: number;
    Age35_39: number;
    Age40_44: number;
    Age45_49: number;
    Age50_54: number;
    Age55_59: number;
    Age5_9: number;
    Age60_64: number;
    Age65_: number;
    Deceased: number;
    Divorced: number;
    ElementarySchool: number;
    Female: number;
    HighSchool: number;
    HigherEducation: number;
    Illiterate: number;
    LiterateUnscholary: number;
    Male: number;
    Married: number;
    NeverMarried: number;
    PrimarySchool: number;
    RehexID: number;
    SecondarySchool: number;
    Total: number;
}

@Injectable()
export class QridPopulationService {
    constructor(public http: HttpClient, public userPreferenceService: UserPreferenceService) {}

    public getQridPopulation(rehexID: number): Observable<QridPopulationResponse> {
        return this.http.get<QridPopulationResponse>(
            `${environment.contentAPIUrl}/api/v1/demography/info/${
                this.userPreferenceService.userSettings.countryCode
            }/${rehexID}`,
        );
    }
}
