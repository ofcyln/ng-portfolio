import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SimilarQridsComponent } from './similar-qrids.component';

describe('SimilarQridsComponent', () => {
    let component: SimilarQridsComponent;
    let fixture: ComponentFixture<SimilarQridsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [SimilarQridsComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SimilarQridsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
