import { Injectable } from '@angular/core';
import * as L from 'leaflet';
import {
    GridLayer,
    LatLngLiteral,
    LayerEvent,
    Map,
    MapOptions,
    PathOptions,
    TileLayer,
} from 'leaflet';
import 'leaflet.gridlayer.googlemutant';
import 'leaflet.vectorgrid';
import 'leaflet.heat';
import 'leaflet-draw';
import { UserPreferenceService, UserSettings } from '../auth/user/user-preference.service';
import { environment } from '../../environments/environment';
import { TranslateService } from '@ngx-translate/core';
import { RangeColorResponse, RangeColorService } from '../auth/data/range-color.service';
import {
    QridPopulationResponse,
    QridPopulationService,
} from '../auth/data/qrid-population.service';
import {
    QridDetailsHeadResponse,
    QridDetailsHeadService,
} from '../auth/data/qrid-details-head.service';
import { AlertService } from '../alert/alert.service';
import { zip } from 'rxjs';
import {
    QridTransportationResponse,
    QridTransportationService,
} from '../auth/data/qrid-transportation.service';
import { QridPoiResponse, QridPoiService } from '../auth/data/qrid-poi.service';

export interface GeojsonProperties {
    options?: object;
    Rehex_Score: number;
    RehexID: number;
    Social_Score: number;
    Population_Score: number;
    Transport_Score: number;
    Poi_Score: number;
}

@Injectable()
export class MapService {
    public mapColors: Array<string>;
    public rangePoints: Array<number>;
    public colorSchema: string;

    public rangeColorResponse: RangeColorResponse;
    public populationDemography: QridPopulationResponse;
    public qridHeadSummary: QridDetailsHeadResponse;
    public qridPoiSummary: QridPoiResponse[];
    public qridTransportationSummary: QridTransportationResponse[];

    public map: Map;
    public mapLatLng: LatLngLiteral;
    public drawnItems: L.FeatureGroup;
    public userSettings: UserSettings;
    public defaultMap: L.gridLayer.GoogleMutant;
    public mapOptions: MapOptions;

    public hoverPopupOptions: PathOptions;
    public itemSummaryPopupOptions: PathOptions;

    public geojsonProperties: GeojsonProperties;
    public highlight: any;
    public qridLayerName: string;

    public terrainMutant: L.gridLayer.GoogleMutant;
    public satelliteMutant: L.gridLayer.GoogleMutant;
    public roadmapMutant: L.gridLayer.GoogleMutant;
    public hybridMutant: L.gridLayer.GoogleMutant;

    public qridLayer: L.vectorGrid.Protobuf;
    public tileLayer: TileLayer;
    public clearHighlight: () => void;

    public vectorTileOptions: L.vectorGrid.VectorGridOptions;
    public wmtsURL: string;

    public detailScreen: boolean;
    public propertyRehexID: number;

    public overallQridScore: string;
    public detailQridScore: string;

    public qridLayerType: string;

    public toggleDetailsScreen: boolean = true;

    public highestRangeValue: number;

    public selectedColorSchema: string;

    public populationScore: number;
    public poiScore: number;
    public transportScore: number;
    public socialScore: number;

    public dataLoaded: boolean = true;

    public selectedCityState: boolean;

    constructor(
        public userPreferenceService: UserPreferenceService,
        public translate: TranslateService,
        public rangeColorService: RangeColorService,
        public qridDemographyPopulationService: QridPopulationService,
        public qridDetailsHeadService: QridDetailsHeadService,
        public qridTransportationService: QridTransportationService,
        public qridPoiService: QridPoiService,
        public alertService: AlertService,
    ) {}

    public initMap() {
        this.initGoogleMutants();
        this.setDefaultMap();
        this.initLeafletMap();
        this.initDrawTool();
        this.initZoom();
        this.setCenterOfMap();
        // this.initHeatmap();
    }

    public initLeafletMap() {
        this.mapOptions = {
            zoomControl: false,
            center: new L.LatLng(
                this.userPreferenceService.userSettings.mapCenter[
                    this.userPreferenceService.userSettings.countryCode
                ].lat,
                this.userPreferenceService.userSettings.mapCenter[
                    this.userPreferenceService.userSettings.countryCode
                ].lng,
            ),
            zoom: this.userPreferenceService.userSettings.zoomLevel || 12,
            minZoom: 4,
            maxZoom: 18,
            layers: [this.defaultMap] || [this.roadmapMutant],
        };
        this.map = L.map('map', this.mapOptions);
    }

    public initZoom() {
        L.control.zoom({ position: 'bottomright' }).addTo(this.map);
    }

    public initHeatmap() {
        L.heatLayer(
            [
                [41.022649536133, 29.040184936523, 0.2],
                [41.022649536134, 29.040184936524, 0.5],
                [41.023649536134, 29.020184936524, 0.5],
            ],
            { radius: 25 },
        ).addTo(this.map);
    }

    public initDrawTool() {
        this.drawnItems = new L.FeatureGroup();
        this.map.addLayer(this.drawnItems);
        let drawControl = new L.Control.Draw({
            position: 'topleft',
            // draw: DrawOptions,
            edit: {
                featureGroup: this.drawnItems,
                edit: {
                    selectedPathOptions: {
                        // this property should be one level up
                        color: '#ef4949',
                        fillColor: '#ef4949',
                    },
                },
                // edit: false,
            },
            draw: {
                // polygon: false,
                marker: false,
                polyline: {
                    shapeOptions: {
                        fillColor: '#000',
                        color: '#000',
                        weight: 3,
                    },
                },
                circlemarker: false,
                rectangle: {
                    shapeOptions: {
                        fillColor: '#000',
                        color: '#000',
                        weight: 1,
                    },
                },
                polygon: {
                    allowIntersection: false,
                    showArea: true,
                    shapeOptions: {
                        fillColor: '#000',
                        color: '#000',
                        weight: 1,
                    },
                },
                circle: {
                    shapeOptions: {
                        fillColor: '#000',
                        color: '#000',
                        weight: 1,
                    },
                },
            },
        });

        this.map.addControl(drawControl);

        this.map.on('draw:created', (event: LayerEvent) => {
            this.drawnItems.addLayer(event.layer);
        });
    }

    public initGoogleMutants() {
        this.terrainMutant = this.getGoogleTile('terrain');
        this.satelliteMutant = this.getGoogleTile('satellite');
        this.roadmapMutant = this.getGoogleTile('roadmap');
        this.hybridMutant = this.getGoogleTile('hybrid');
    }

    public getGoogleTile(type: L.gridLayer.GoogleMutantType) {
        return L.gridLayer.googleMutant({
            type: type,
        });
    }

    public setActiveLayer(layer: GridLayer) {
        this.map.removeLayer(this.roadmapMutant);
        this.map.removeLayer(this.satelliteMutant);
        this.map.removeLayer(this.terrainMutant);
        this.map.removeLayer(this.hybridMutant);
        layer.addTo(this.map);
    }

    public setDefaultMap() {
        switch (this.userPreferenceService.userSettings.activeMap) {
            case 'roadmap':
                this.defaultMap = this.getGoogleTile('roadmap');
                break;
            case 'satellite':
                this.defaultMap = this.getGoogleTile('satellite');
                break;
            case 'terrain':
                this.defaultMap = this.getGoogleTile('terrain');
                break;
            case 'hybrid':
                this.defaultMap = this.getGoogleTile('hybrid');
                break;
            default:
                this.defaultMap = this.getGoogleTile('roadmap');
                break;
        }
    }

    public onMapZoom() {
        this.userPreferenceService.userSettings = {
            ...this.userPreferenceService.userSettings,
            zoomLevel: this.map.getZoom(),
        };
    }

    public onMapMove() {
        this.userPreferenceService.userSettings = {
            ...this.userPreferenceService.userSettings,
            mapCenter: {
                ...this.userPreferenceService.userSettings.mapCenter,
                [this.userPreferenceService.userSettings.countryCode]: this.map.getCenter(),
            },
        };
    }

    public onMapTypeChange(activeMap: string) {
        this.userPreferenceService.userSettings = {
            ...this.userPreferenceService.userSettings,
            activeMap,
        };
    }

    public setCenterOfMap() {
        this.mapLatLng = this.userPreferenceService.userSettings.mapCenter[
            this.userPreferenceService.userSettings.countryCode
        ];

        this.map.panTo(this.mapLatLng);

        this.map.on('moveend', () => {
            this.onMapMove();
        });
    }

    public setCityBounds(
        lowerLeftY: number,
        lowerLeftX: number,
        upperRightY: number,
        upperRightX: number,
    ) {
        if (this.qridLayer) {
            this.qridLayer.remove();
            this.map.closePopup();
        }

        this.map.fitBounds([[lowerLeftY, lowerLeftX], [upperRightY, upperRightX]]);
    }

    public getColorSchema(rehexID: string) {
        this.selectedColorSchema = '';

        switch (rehexID) {
            case 'Rehex':
                this.selectedColorSchema = 'RedPurple';
                break;
            case 'Poi':
                this.selectedColorSchema = 'YellowGreen';
                break;
            case 'Social':
                this.selectedColorSchema = 'YellowGreenBlue';
                break;
            case 'Population':
                this.selectedColorSchema = 'YellowOrangeRed';
                break;
            case 'Transport':
                this.selectedColorSchema = 'PurpleBlueGreen';
                break;

            default:
                this.selectedColorSchema = 'RedPurple';
                break;
        }

        return this.selectedColorSchema;
    }

    public getQridColors(cityID: number, rehexID: string) {
        let mvtStyle = {
            [this.qridLayerName]: (properties: any) => {
                let rehexScore = properties.Rehex_Score;

                switch (rehexID) {
                    case 'Rehex':
                        rehexScore = properties.Rehex_Score.toFixed(2);
                        break;
                    case 'Social':
                        rehexScore = properties.Social_Score.toFixed(2);
                        break;
                    case 'Poi':
                        rehexScore = properties.Poi_Score.toFixed(2);
                        break;
                    case 'Population':
                        rehexScore = properties.Population_Score.toFixed(2);
                        break;
                    case 'Transport':
                        rehexScore = properties.Transport_Score.toFixed(2);
                        break;

                    default:
                        rehexScore = properties.Rehex_Score.toFixed(2);
                        break;
                }

                for (let i = 0; i < this.rangePoints.length; i++) {
                    const valMax = this.rangePoints[i];

                    if (rehexScore <= valMax) {
                        return {
                            weight: 1,
                            fillColor: this.mapColors[i],
                            fillOpacity: 0.5,
                            fill: true,
                            stroke: true,
                            color: 'white',
                        };
                    }
                }
            },
        };

        return mvtStyle;
    }

    public selectQridScore(type: string) {
        let qridType = '';

        let rehexProgress = this.geojsonProperties.Rehex_Score.toFixed();
        let populationScore = this.geojsonProperties.Population_Score.toFixed();
        let socialScore = this.geojsonProperties.Social_Score.toFixed();
        let poiScore = this.geojsonProperties.Poi_Score.toFixed();
        let transportScore = this.geojsonProperties.Transport_Score.toFixed();

        switch (type) {
            case 'Rehex':
                qridType = rehexProgress;
                break;
            case 'Social':
                qridType = socialScore;
                break;
            case 'Poi':
                qridType = poiScore;
                break;
            case 'Population':
                qridType = populationScore;
                break;
            case 'Transport':
                qridType = transportScore;
                break;
            default:
                qridType = rehexProgress;
                break;
        }

        return qridType;
    }

    public getPopupTranslates(translateText: string) {
        let translatedText = '';

        switch (translateText) {
            case 'qrid-score':
            case 'qrid-point':
            case 'see-details':
            case 'region-summary':
            case 'score':
            case 'Rehex':
            case 'Social':
            case 'Population':
            case 'Transport':
            case 'Poi':
            case 'population-density':
            case 'transport-density':
            case 'social-density':
            case 'poi-density':
            case 'rental-prices':
                translatedText = this.translate.instant(`main.views.qrid-layers.${translateText}`);
                break;

            default:
                translatedText = this.translate.instant(
                    'main.general.messages.error.general-error',
                );
                break;
        }

        return translatedText;
    }

    public selectedTranslate(rehexID: string) {
        let toBeTranslated = '';

        switch (rehexID) {
            case 'Rehex':
            case 'Population':
            case 'Poi':
            case 'Social':
            case 'Transport':
                toBeTranslated = this.getPopupTranslates(rehexID);
                break;
            default:
                toBeTranslated = this.translate.instant(
                    'main.general.messages.error.general-error',
                );
                break;
        }

        return toBeTranslated;
    }

    public addQridLayer(cityID: number, rehexID: string) {
        this.qridLayerName = 'qrid';

        this.clearHighlight = () => {
            if (this.highlight) {
                this.qridLayer.resetFeatureStyle(this.highlight);
            }
            this.highlight = null;
        };

        this.colorSchema = this.getColorSchema(rehexID);
        this.dataLoaded = false;
        console.log('requests done & data loaded:', this.dataLoaded);

        this.rangeColorService
            .getRangeColors(cityID, rehexID, this.colorSchema)
            .subscribe((response) => {
                this.rangeColorResponse = response;

                this.rangePoints = this.rangeColorResponse[cityID][rehexID].ClassBreaks;

                this.mapColors = this.rangeColorResponse[cityID][rehexID].ColorPalette;

                this.vectorTileOptions = {
                    vectorTileLayerStyles: this.getQridColors(cityID, rehexID),
                    interactive: true,
                    getFeatureId: (f: any) => {
                        return f.properties.RehexID;
                    },
                };

                let currentUser = JSON.parse(localStorage.getItem('currentUser'));

                this.wmtsURL = `${environment.contentAPIUrl}/api/v1/tiles/qrid/${
                    this.userPreferenceService.userSettings.countryCode
                }/${cityID}/{z}/{x}/{y}.mvt?access_token=${
                    currentUser.access_token
                }&factor_key=${rehexID}`;

                this.qridLayer = L.vectorGrid
                    .protobuf(this.wmtsURL, this.vectorTileOptions)
                    .on('mouseover', (event: any) => {
                        this.geojsonProperties = event.layer.properties;

                        this.hoverPopupOptions = {
                            className: 'protobuf-popup',
                        };

                        // to calculate progress of the range values, this is max value
                        this.highestRangeValue = this.rangeColorResponse[cityID][
                            rehexID
                        ].ClassBreaks[
                            this.rangeColorResponse[cityID][rehexID].ClassBreaks.length - 1
                        ];

                        let overallQridScore = this.selectQridScore(rehexID);

                        L.popup(this.hoverPopupOptions)
                            .setContent(
                                `
                            <b class="rehex-heading font-13">${this.selectedTranslate(
                                rehexID,
                            )} ${this.getPopupTranslates('score')}</b>
                            <div class="progress-radial progress-${overallQridScore}"><b></b></div>
                            `,
                            )
                            .setLatLng(event.latlng)
                            .openOn(this.map);

                        this.clearHighlight();

                        this.highlight = this.geojsonProperties.RehexID;

                        let style = {
                            stroke: true,
                            fill: true,
                            color: '#d22121',
                            weight: 3,
                        };

                        this.qridLayer.setFeatureStyle(this.geojsonProperties.RehexID, style);
                    })
                    .on('click', (event: any) => {
                        this.detailScreen = false;
                        // console.log(event, 'Clicked!');
                        this.geojsonProperties = event.layer.properties;

                        // let rehexScore = this.geojsonProperties.Rehex_Score.toFixed();
                        let population = this.geojsonProperties.Population_Score.toFixed();
                        let socialScore = this.geojsonProperties.Social_Score.toFixed();
                        let poiScore = this.geojsonProperties.Poi_Score.toFixed();
                        let transportScore = this.geojsonProperties.Transport_Score.toFixed();

                        this.overallQridScore = this.selectQridScore(rehexID);

                        // show what's coming
                        // console.log('max value of the range:', this.highestRangeValue);
                        // console.table(this.geojsonProperties);

                        this.itemSummaryPopupOptions = {
                            className: 'item-summary-popup',
                        };

                        L.popup(this.itemSummaryPopupOptions)
                            .setContent(
                                `
                        <div class="row no-margin summary-area">
                            <div class="summary-left-pane no-padding padding-right-md col-8 padding-top-lg 
                            padding-left-md padding-bottom-lg">
                                <div class="col-12 layout-row no-padding align-items-center short-detail-item">
                                    <div class="ricon-population summary-icon margin-right-sm"></div>
                                     <div class="item-summary-name col-5 no-padding font-11">
                                        ${this.selectedTranslate('Population') +
                                            ' ' +
                                            this.getPopupTranslates('score')}
                                    </div>
                                    <div class="item-linear-progress no-padding col-4 margin-left-sm margin-right-sm">
                                        <div class="linear-progress-bar">
                                            <div class="progress-value" style="width:${population}%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 layout-row no-padding align-items-center short-detail-item 
                                margin-top-sm padding-top-lg margin-bottom-lg">
                                    <div class="ricon-social summary-icon margin-right-sm"></div>
                                     <div class="item-summary-name col-5 no-padding font-11">
                                        ${this.selectedTranslate('Social') +
                                            ' ' +
                                            this.getPopupTranslates('score')}
                                        </div>
                                    <div class="item-linear-progress no-padding col-4 margin-left-sm margin-right-sm">
                                        <div class="linear-progress-bar">
                                            <div class="progress-value" style="width:${socialScore}%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12 layout-row no-padding align-items-center short-detail-item 
                                margin-top-sm padding-top-lg">
                                    <div class="ricon-poi summary-icon margin-right-sm"></div>
                                     <div class="item-summary-name col-5 no-padding font-11">
                                        ${this.selectedTranslate('Poi') +
                                            ' ' +
                                            this.getPopupTranslates('score')}
                                    </div>
                                    <div class="item-linear-progress no-padding col-4 margin-left-sm margin-right-sm">
                                        <div class="linear-progress-bar">
                                            <div class="progress-value" style="width:${poiScore}%">
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                
                                <div class="col-12 layout-row no-padding align-items-center short-detail-item 
                                margin-top-md padding-top-xlg">
                                    <div class="ricon-poi summary-icon margin-right-sm"></div>
                                     <div class="item-summary-name col-5 no-padding font-11">
                                        ${this.selectedTranslate('Transport') +
                                            ' ' +
                                            this.getPopupTranslates('score')}
                                    </div>
                                    <div class="item-linear-progress no-padding col-4 margin-left-sm margin-right-sm">
                                        <div class="linear-progress-bar">
                                            <div class="progress-value" style="width:${transportScore}%">
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="summary-right-pane seperator-left col-4 no-padding layout-column 
                            align-items-center padding-lg">
                                <h2 class="summary-heading font-15 align-center 
                                margin-top-lg">${this.getPopupTranslates('region-summary')}</h2>
                                <p class="summary-qrid font-12 align-center">${this.selectedTranslate(
                                    rehexID,
                                )} ${this.getPopupTranslates('score')}</p>
                                <div class="progress-radial progress-${
                                    this.overallQridScore
                                }"><b></b></div>
                                <a class="summary-details font-12 border-radius-md cursor-pointer 
                                margin-top-lg align-center">${this.getPopupTranslates(
                                    'see-details',
                                )}</a>
                            </div>
                        </div>
                        `,
                            )
                            .setLatLng(event.latlng)
                            .openOn(this.map);

                        let seeDetailsElement = document.querySelector('.summary-details');
                        seeDetailsElement.addEventListener('click', () => {
                            this.propertyRehexID = this.geojsonProperties.RehexID;

                            this.detailScreen = false;

                            // toggling detail screen
                            this.toggleDetailsScreen = true;

                            this.qridLayerType = rehexID;

                            // observable API combine
                            zip(
                                this.qridDemographyPopulationService.getQridPopulation(
                                    this.propertyRehexID,
                                ),
                                this.qridDetailsHeadService.getQridDetailsHeadSummary(
                                    this.propertyRehexID,
                                ),
                                this.qridTransportationService.getQridTransportation(
                                    this.propertyRehexID,
                                ),
                                this.qridPoiService.getQridPoi(this.propertyRehexID),
                            ).subscribe(
                                (result) => {
                                    this.populationDemography = result[0];
                                    this.qridHeadSummary = result[1];
                                    this.qridTransportationSummary = result[2];
                                    this.qridPoiSummary = result[3];
                                },
                                (error) => {
                                    this.alertService.error(
                                        `Error while getting data from server: ${error.message}!`,
                                    );

                                    this.dataLoaded = true;
                                    console.log(
                                        "requests failed & data can't be loaded because of an error:",
                                        this.dataLoaded,
                                    );
                                },
                                () => {
                                    // console.log('Population Demography', this.populationDemography);
                                    this.detailScreen = true;
                                },
                            );

                            // overall score
                            this.detailQridScore = this.overallQridScore;

                            // delayed scores
                            this.socialScore = this.geojsonProperties.Social_Score;
                            this.poiScore = this.geojsonProperties.Poi_Score;
                            this.populationScore = this.geojsonProperties.Population_Score;
                            this.transportScore = this.geojsonProperties.Transport_Score;

                            // console.log('GET populationDemography', this.populationDemography);
                        });
                    });

                this.tileLayer = L.tileLayer(
                    `${environment.contentAPIUrl}/api/v1/tiles/qrid/${
                        this.userPreferenceService.userSettings.countryCode
                    }/${cityID}/{z}/{x}/{y}.png?access_token=${
                        currentUser.access_token
                    }&factor_key=${rehexID}`,
                    {
                        layers: 'REIDIN:Demo_Retail',
                        format: 'image/png',
                        transparent: true,
                        attribution: 'REIDIN QRID Data © 2018',
                        minZoom: 8,
                        maxZoom: 12,
                    },
                );

                this.dataLoaded = true;
                console.log('requests done & data loaded:', this.dataLoaded);

                if (this.userPreferenceService.userSettings.zoomLevel >= 13) {
                    this.map.removeLayer(this.tileLayer);
                    this.map.closePopup();
                    this.map.addLayer(this.qridLayer);
                    // this.map.on('click', this.clearHighlight);
                } else if (this.userPreferenceService.userSettings.zoomLevel < 13) {
                    this.map.closePopup();
                    this.map.removeLayer(this.qridLayer);
                    this.map.addLayer(this.tileLayer);
                }
            });
    }
}
