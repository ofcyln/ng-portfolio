import { Component, OnInit } from '@angular/core';
import { MapService } from '../shared/map.service';
import { UserPreferenceService } from '../auth/user/user-preference.service';
import * as L from 'leaflet';
import { UserService } from '../auth/user/user.service';
import { AlertService } from '../alert/alert.service';

@Component({
    selector: 'rdm-map',
    templateUrl: './map.component.html',
    styleUrls: ['./map.component.scss'],
})
export class MapComponent implements OnInit {
    constructor(
        public mapService: MapService,
        public userPreferenceService: UserPreferenceService,
        public userService: UserService,
        public alertService: AlertService,
    ) {}

    ngOnInit() {
        this.mapService.initMap();

        this.addZoomControl();
    }

    public addZoomControl() {
        let zoomArea = L.Control.extend({
            options: {
                position: 'bottomright',
            },
            onAdd: () => {
                let currentZoomArea = document
                    .getElementsByClassName('leaflet-control-zoom')
                    .item(0);

                let gauge = L.DomUtil.create('div');
                gauge.classList.add('leaflet-control-current-zoom');

                gauge.innerHTML = this.mapService.map.getZoom().toString();

                this.mapService.map.on('zoom', () => {
                    gauge.innerHTML = this.mapService.map.getZoom().toString();
                    this.mapService.onMapZoom();
                });

                currentZoomArea.appendChild(gauge);

                return currentZoomArea;
            },
        });

        new zoomArea().addTo(this.mapService.map);
    }
}
