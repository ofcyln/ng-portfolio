// // OOP (Nesne yonelimi, bir nesne olusturmak ve bunu bir class a esitlemek)
//
// export class Welcomer {
//     // karbon kagidi gibi dusunulebilir
//     public hey: string; // OOP deki property ile JS deki Object Property farkli
//
//     constructor(message: string) {
//         this.sayHi(message);
//     }
//
//     public sayHi(message: string) {
//         console.log(message);
//     }
// }
//
// let a = new Welcomer('Hi!'); // karbon kagidi sayesinde reeal bir kagit olusturulmus olarak dusunulebilir
//
// // yukaridaki ornegin asagidaki vanilla JS yazima gore yazimi ODEV
// function Greeter(greeting) {
//     this.greeting = greeting;
// }
//
// Greeter.prototype.greet = function() {
//     return 'Hello, ' + this.greeting;
// };
//
// // Oops, we're passing an object when we want a string. This will print
// // "Hello, [object Object]" instead of "Hello, world" without error.
// let greeter = new Greeter({ message: 'world' });
//
// let button = document.createElement('button');
// button.textContent = 'Say Hello';
// button.onclick = function() {
//     alert(greeter.greet());
// };
//
// document.body.appendChild(button);
//
// // OOP (Nesne yonelimi, bir nesne olusturmak ve bunu bir class a esitlemek)
//
// export class Tape {
//     public time: number;
//     public size: string;
//
//     constructor(time: number, size: string) {
//         this.time = time;
//         this.size = size;
//     }
// }
//
// export class Vhs extends Tape {
//     public brand: string;
//
//     constructor(brand: string, time: number) {
//         super(time, '5x4');
//         this.brand = brand;
//     }
// }
//
// export class RaksVhs extends Vhs {
//     constructor(time: number) {
//         super('Raks', time);
//         this.time = 2 * time;
//     }
// }
//
// let raksCasette = new RaksVhs(90);
//
// console.log(raksCasette);
