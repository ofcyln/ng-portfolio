import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DensityComponent } from './density.component';
import { MapService } from '../../../shared/map.service';

class MockMapService {
    socialScore = 12.1234;
    poiScore = 72.1234;
    populationScore = 32.1234;
    transportScore = 52.1234;
    // initMap() {
    //     console.log('initMap fired!');
    // }
}

describe('Density Component', () => {
    let comp: DensityComponent;
    let fixture: ComponentFixture<DensityComponent>;
    // let service: DensityService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            // TestBed dependencyleri olusturmak icin kullanildi
            declarations: [DensityComponent],
            providers: [
                // mapService ve alt dependency lerini import etmemek icin
                // DensityService,
                {
                    provide: MapService,
                    useClass: MockMapService, // useFactory bu da factory function dir
                },
            ],
        });

        fixture = TestBed.createComponent(DensityComponent);
        comp = fixture.componentInstance; // service = TestBed.get(DensityService);
        // comp = TestBed.get(DensityComponent);
    });

    it('should render', () => {
        console.log(comp);
        expect(comp).toBeDefined();
    });

    describe('while displaying density score should set a progress bar based on', () => {
        // let initMapSpy: jasmine.Spy;

        // beforeEach(() => {
        //     // araya girip methodu cagirmadan calisip calismadigini kontrol eder,
        //     // bir degisken icinde cagirmanin tek sebebi degisken ile cagrilari secip return
        //     // valuelarina ve ya cagri parametrelerine ulasmak
        //     initMapSpy = spyOn(comp.mapService, 'initMap');
        //
        //     // // spy hem araya girer hem methodun calismasini saglar
        //     // initMapSpy = spyOn(comp.mapService, 'initMap').and.callThrough();
        //
        //     // // araya girer ve methodun fake bir methodla calismasini saglar
        //     // initMapSpy = spyOn(comp.mapService, 'initMap').and.callFake(() => {
        //     //     // callfake icindeki parametre spy ile cagirdigin methodun parametresi
        //     //     console.log('Fikret!');
        //     // });
        // });
        //
        // it('should call initMap method on init', () => {
        //     comp.ngOnInit();
        //     expect(comp.mapService.initMap).toHaveBeenCalled();
        //     expect(initMapSpy.calls.mostRecent().args); // eger boyle bir
        // ihtiyac yoksa spyOn u bir degiskene atamana gerek yok
        // });

        it('social score', () => {
            const socialElement = fixture.nativeElement.querySelector('[data-qa="social-score"]');
            // expect(socialElement.style.width).toBe('12.12%'); // bu mock degeri ayni kaldigi surece calisir
            expect(socialElement.style.width).toBe(
                Number(comp.mapService.socialScore).toFixed(2) + '%',
            );
        });

        it('poi score', () => {
            const socialElement = fixture.nativeElement.querySelector('[data-qa="poi-score"]');
            expect(socialElement.style.width).toBe(
                Number(comp.mapService.poiScore).toFixed(2) + '%',
            );
        });

        it('transport score', () => {
            const socialElement = fixture.nativeElement.querySelector(
                '[data-qa="transport-score"]',
            );
            expect(socialElement.style.width).toBe(
                Number(comp.mapService.transportScore).toFixed(2) + '%',
            );
        });

        it('population score', () => {
            const socialElement = fixture.nativeElement.querySelector(
                '[data-qa="population-score"]',
            );
            expect(socialElement.style.width).toBe(
                Number(comp.mapService.populationScore).toFixed(2) + '%',
            );
        });
    });
});
