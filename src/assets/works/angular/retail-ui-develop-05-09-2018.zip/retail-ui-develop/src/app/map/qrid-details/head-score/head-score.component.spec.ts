import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeadScoreComponent } from './head-score.component';

describe('HeadScoreComponent', () => {
    let component: HeadScoreComponent;
    let fixture: ComponentFixture<HeadScoreComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HeadScoreComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HeadScoreComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
