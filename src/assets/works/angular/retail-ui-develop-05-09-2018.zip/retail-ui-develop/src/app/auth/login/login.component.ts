import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { UserPreferenceService, UserSettings } from '../user/user-preference.service';
import { AuthenticationService } from '../authentication.service';
import { AlertService } from '../../alert/alert.service';
import { ModalDismissReasons, NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { MapService } from '../../shared/map.service';

export interface Language {
    title: string;
    selected: boolean;
}

@Component({
    moduleId: module.id,
    selector: 'rdm-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
    @ViewChild('multipleDeviceModalTemplate') multipleDeviceModalContent: ElementRef;
    modalOption: NgbModalOptions = {};

    public selectedLanguage = 'Select Language';
    public languages: string[] = [];

    public isAuthenticated: boolean;
    public username: string;
    public password = '';
    public modalToken: string;

    public model: any = {};
    public loading = false;
    public modalLoading = false;
    public returnUrl: string;

    public userSettings: UserSettings;

    public animationActive: boolean;
    public modalAnimationActive: boolean;

    constructor(
        public router: Router, // public router = new Router();
        public translate: TranslateService,
        public userPreferenceService: UserPreferenceService,
        private route: ActivatedRoute,
        private authenticationService: AuthenticationService,
        private alertService: AlertService,
        public modalService: NgbModal,
        public mapService: MapService,
    ) {}

    ngOnInit() {
        // reset login status
        this.authenticationService.logout();

        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';

        this.authenticationService.deviceIdControl();

        this.languages = this.translate.getLangs();
        this.selectedLanguage = this.translate.getDefaultLang();
        console.log(this.translate.getLangs());

        this.userSettings = this.userPreferenceService.userSettings;

        this.modalOption.backdrop = 'static';
        this.modalOption.keyboard = false;
    }

    login() {
        this.loading = true;
        this.animationActive = !this.animationActive;

        this.authenticationService.login(this.model.username, this.model.password).subscribe(
            (response) => {
                if (response.code === '107') {
                    this.openMultipleDeviceModal();
                }

                this.router.navigate([this.returnUrl]);
            },
            (error) => {
                this.errorTypeDefinitions(error.error.code);

                // console.log(error);

                this.loading = false;
                this.animationActive = false;
            },
        );
    }

    addDevice() {
        this.modalLoading = true;
        this.modalAnimationActive = !this.modalAnimationActive;

        this.authenticationService.addDevice(this.model.modalToken).subscribe(
            (response) => {
                let customMessage = '';

                if (response.message) {
                    customMessage = this.translate.instant(
                        'main.general.messages.success.device-id-updated',
                    );
                } else {
                    customMessage = this.translate.instant(
                        'main.general.messages.error.general-error',
                    );
                }

                this.alertService.success(customMessage);

                setTimeout(() => {
                    return (window.location.href = '/');
                }, 3000);
            },
            (error) => {
                this.errorTypeDefinitions(error.error.code);

                this.modalLoading = false;
                this.modalAnimationActive = false;
            },
        );
    }

    public openMultipleDeviceModal() {
        this.modalService.open(this.multipleDeviceModalContent, this.modalOption).result.then(
            (result) => {
                console.log(`Closed with: ${result}`);
            },
            (reason) => {
                console.log(`Dismissed ${this.getDismissReason(reason)}`);
            },
        );
    }

    public switchLanguage(language: string) {
        this.translate.use(language);
        this.selectedLanguage = language;
        this.userSettings.language = language;
        this.userPreferenceService.userSettings = this.userSettings;
    }

    public onPasswordChange(value: string) {
        console.log(value);
    }

    public navigateToHomePage(f: NgForm) {
        console.log(f.value);
        console.log(this.username);
        console.log(this.password);
        if (f.valid && this.isAuthenticated) {
            this.router.navigate(['/home']);
        } else {
            f.resetForm();
        }
    }

    public setSelectedLanguage(language: Language) {
        this.selectedLanguage = language.title;
    }

    public errorTypeDefinitions(errorResponse: string) {
        let responseMessage = '';

        switch (errorResponse) {
            case '100':
            case '102':
            case '106':
            case '108':
            case '400':
            case '401':
            case '404':
            case '500':
                responseMessage = this.translate.instant(
                    `main.general.messages.error.${errorResponse}`,
                );
                break;

            default:
                responseMessage = this.translate.instant(
                    'main.general.messages.error.general-error',
                );
                break;
        }

        this.alertService.error(responseMessage);
    }

    private getDismissReason(reason: {}): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }
}
