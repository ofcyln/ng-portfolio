import { Injectable } from '@angular/core';
import { UserPreferenceService } from '../user/user-preference.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface QridTransportationResponse {
    SubTypeID: number;
    Category: string;
    Poi_Distance: number;
    Poi_ID: number;
    Poi_name: string;
    Poi_count: number;
}

@Injectable()
export class QridTransportationService {
    constructor(public http: HttpClient, public userPreferenceService: UserPreferenceService) {}

    public getQridTransportation(rehexID: number): Observable<QridTransportationResponse[]> {
        return this.http.get<QridTransportationResponse[]>(
            `${environment.contentAPIUrl}/api/v1/transportation/summary/${
                this.userPreferenceService.userSettings.countryCode
            }/${rehexID}`,
        );
    }
}
