import { Component, HostBinding, OnInit } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';

export interface OfficeCategory {
    title: string;
    id: number;
}

@Component({
    selector: 'rdm-office',
    templateUrl: './office.component.html',
    styleUrls: ['./office.component.scss'],
    animations: [slideInLeftAnimation],
})
export class OfficeComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    public selectedOfficeCategory = 'Select Price Type';
    public officeCategories: OfficeCategory[];

    constructor() {}

    ngOnInit() {
        this.initOfficeCategoryData();
    }

    private initOfficeCategoryData(): void {
        this.officeCategories = [
            { title: '1. El Satış TL / m²', id: 0 },
            { title: '1. El Satış', id: 1 },
            { title: 'Kira m²', id: 2 },
            { title: '2. El Satış TL / m²', id: 3 },
            { title: '2. El Satış', id: 4 },
        ];
    }
}
