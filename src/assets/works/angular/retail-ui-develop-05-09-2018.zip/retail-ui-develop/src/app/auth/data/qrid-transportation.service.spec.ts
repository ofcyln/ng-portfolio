import { TestBed, inject } from '@angular/core/testing';

import { QridTransportationService } from './qrid-transportation.service';

describe('QridTransportationService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [QridTransportationService],
        });
    });

    it('should be created', inject(
        [QridTransportationService],
        (service: QridTransportationService) => {
            expect(service).toBeTruthy();
        },
    ));
});
