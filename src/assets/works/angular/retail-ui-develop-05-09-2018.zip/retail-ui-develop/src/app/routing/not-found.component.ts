import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
    templateUrl: './not-found.component.html',
    styleUrls: ['./not-found.component.scss'],
})
export class PageNotFoundComponent {
    constructor(public router: Router, public translate: TranslateService) {}
}
