import { Component, HostBinding, OnInit } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';
import { UserPreferenceService, UserSettings } from '../../auth/user/user-preference.service';
import { MapService } from '../../shared/map.service';
import * as L from 'leaflet';

@Component({
    selector: 'rdm-map-type',
    templateUrl: './map-type.component.html',
    styleUrls: ['./map-type.component.scss'],
    animations: [slideInLeftAnimation],
})
export class MapTypeComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    public activeMap: string;
    public userSettings: UserSettings;

    constructor(
        public userPreferenceService: UserPreferenceService,
        public mapService: MapService,
    ) {}

    ngOnInit() {
        this.userSettings = this.userPreferenceService.userSettings;
        // this.userPreferenceService.userSettings.activeMap = this.activeMap;
    }

    public setMapType(type: L.gridLayer.GoogleMutantType) {
        switch (type) {
            case 'roadmap':
                this.mapService.setActiveLayer(this.mapService.roadmapMutant);
                this.mapService.onMapTypeChange('roadmap');
                break;
            case 'satellite':
                this.mapService.setActiveLayer(this.mapService.satelliteMutant);
                this.mapService.onMapTypeChange('satellite');
                break;
            case 'terrain':
                this.mapService.setActiveLayer(this.mapService.terrainMutant);
                this.mapService.onMapTypeChange('terrain');
                break;
            case 'hybrid':
                this.mapService.setActiveLayer(this.mapService.hybridMutant);
                this.mapService.onMapTypeChange('hybrid');
                break;

            default:
                this.mapService.setActiveLayer(this.mapService.roadmapMutant);
                this.mapService.onMapTypeChange('roadmap');
                break;
        }
    }
}
