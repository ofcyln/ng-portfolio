import { Component, HostBinding, OnInit } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';

@Component({
    selector: 'rdm-poi',
    templateUrl: './poi.component.html',
    styleUrls: ['./poi.component.scss'],
    animations: [slideInLeftAnimation],
})
export class PoiComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    constructor() {}

    ngOnInit() {}
}
