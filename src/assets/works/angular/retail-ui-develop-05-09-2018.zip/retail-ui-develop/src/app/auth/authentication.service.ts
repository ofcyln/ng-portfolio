import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { StorageService } from '../shared/storage.service';
import { LoginResponse } from '../models/users';
import { environment } from '../../environments/environment';
import { tap } from 'rxjs/operators';
import { UserService } from './user/user.service';

@Injectable()
export class AuthenticationService {
    // public currentUserParameters: RequestParameters;

    constructor(
        private http: HttpClient,
        public router: Router,
        public storageService: StorageService,
        public userService: UserService,
    ) {}

    ngOnInit() {}

    createDeviceId() {
        return Math.floor(1000000000 + Math.random() * 9000000000);
    }

    setDeviceId() {
        this.storageService.setObject('device_id', this.createDeviceId());
    }

    // TODO: localStorage kullanma yerine storageService methodlarini kullan
    deviceIdControl() {
        let getDeviceId = JSON.parse(localStorage.getItem('device_id'));

        if (!getDeviceId) {
            this.setDeviceId();
        }

        return false;
    }

    login(username: string, password: string) {
        let body = new FormData();

        body.append('username', username);
        body.append('password', password);
        body.append('grant_type', 'password');
        body.append('device_id', JSON.parse(this.storageService.getItem('device_id')));

        return this.http.post<LoginResponse>(`${environment.baseAPIUrl}/login`, body).pipe(
            // rxjs operatorleri yazilir pipe icine
            tap((user) => {
                if (user && user.access_token) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(user));
                }
            }),
            tap((loginResponse) => {
                this.userService.setUser(loginResponse.user);
            }),
        );

        // return Observable.of(<LoginResponse>{
        // // http get gibi bir observable degilse ya da herhangi,
        // // observable off kullanilir, subscribe etmeden degerini
        // // kullanamazsin zaten bu user.service de acikca goruluyor,
        // // dataya erisim icin subscribe olman gerekli
        //     access_token: 'DKjmCymHjrrhjMHldaNReryqtpMh8v7RwfHJS32UCD',
        //     expires_in: 86400,
        //     code: '200',
        //     client_id: 'reidin',
        //     device_id: '1231243232431231',
        //     expired_at: '2018-06-24 11:58:45',
        //     token_type: 'Bearer',
        //     user: {
        //         admin: true,
        //         closed: false,
        //         company: null,
        //         created_at: '2018-06-12T11:07:34.728376+00:00',
        //         crm_user_id: null,
        //         email: 'internal@internal.com',
        //         free_session: true,
        //         id: 27012,
        //         is_active: true,
        //         logout_option: true,
        //         mobile_option: true,
        //         mobile_phone: null,
        //         multiple_device_option: true,
        //         name: 'internal_test',
        //         products: [],
        //         provider: null,
        //         session_count: 1,
        //         status: true,
        //         updated_at: '2018-06-12T11:07:34.728425+00:00'
        //     }
        // }).pipe( // rxjs operatorleri yazilir pipe icine
        //     tap((user) => {
        //         if (user && user.access_token) {
        //             // store user details and jwt token in local storage
        //             // to keep user logged in between page refreshes
        //             localStorage.setItem('currentUser', JSON.stringify(user));
        //         }
        //     }),
        //     tap((loginResponse) => {
        //         this.userService.setUser(loginResponse.user);
        //     })
        // )
    }

    logout() {
        this.storageService.removeObject('currentUser');

        this.router.navigate(['/login']);
    }

    addDevice(token: string) {
        return this.http.get<LoginResponse>(
            `${environment.baseAPIUrl}/users/add_device?token=${token}`,
        );
    }
}
