import {
    Component,
    ElementRef,
    EventEmitter,
    HostBinding,
    OnInit,
    ViewChild,
    ViewEncapsulation,
} from '@angular/core';
import { slideInLeftAnimation } from '../../animations';
import { UploaderOptions, UploadFile, UploadInput, UploadOutput } from 'ngx-uploader';
import { environment } from '../../../environments/environment';
import {
    PatchFileResponse,
    UserFileResponse,
    UserFilesService,
} from '../../auth/data/user-files.service';
import { AlertService } from '../../alert/alert.service';
import { ModalDismissReasons, NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { MapService } from '../../shared/map.service';
import { MyDataService, UserFileResponseExtended } from './my-data.service';

@Component({
    selector: 'rdm-my-data',
    templateUrl: './my-data.component.html',
    styleUrls: ['./my-data.component.scss'],
    animations: [slideInLeftAnimation],
    encapsulation: ViewEncapsulation.None,
})
export class MyDataComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    @ViewChild('editFileNameModalTemplate') editFileNameModalContent: ElementRef;
    modalOption: NgbModalOptions = {};

    public options: UploaderOptions;
    public formData: FormData;
    public files: UploadFile[];
    public uploadInput: EventEmitter<UploadInput>;
    public uploadFileOutput: EventEmitter<UploadOutput>;
    public humanizeBytes: Function;
    public dragOver: boolean;
    public contentLoaded: boolean = false;
    public selectedFileResponse: UserFileResponse;

    public userFiles: UserFileResponseExtended[];

    public fileID: string = '';
    public fileAlias: string = '';
    public selectedFileAlias: string = '';

    public uploadEvent: UploadInput;

    constructor(
        public userFilesService: UserFilesService,
        public alertService: AlertService,
        public modalService: NgbModal,
        public mapService: MapService,
        public myDataService: MyDataService,
    ) {
        this.options = {
            concurrency: 1,
            maxUploads: 10,
            allowedContentTypes: [
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/msexcel',
            ],
        };
        this.files = []; // local uploading files array
        this.uploadInput = new EventEmitter<UploadInput>(); // input events, we use this to emit data to ngx-uploader
    }

    ngOnInit() {
        this.getUserFiles();

        this.modalOption.backdrop = 'static';
        this.modalOption.keyboard = false;
    }

    getUserFiles() {
        this.userFilesService.getUserFiles().subscribe(
            (response: UserFileResponseExtended[]) => {
                this.userFiles = response;
                this.contentLoaded = true;
            },
            (error) => {
                this.alertService.error(error.message);
            },
        );
    }

    onUploadOutput(output: UploadOutput): void {
        if (output.type === 'allAddedToQueue') {
            // when all files added in queue
            this.uploadInput.emit(this.uploadEvent);
        } else if (output.type === 'addedToQueue' && typeof output.file !== 'undefined') {
            // add file to array when added
            if (output.file.size > 1000000) {
                this.alertService.error(
                    'Allowed file size is 1Mb, your file is bigger than allowed size!',
                );
            } else {
                this.files.push(output.file);
            }
        } else if (output.type === 'uploading' && typeof output.file !== 'undefined') {
            // update current data in files array for uploading file
            const index = this.files.findIndex(
                (file) => typeof output.file !== 'undefined' && file.id === output.file.id,
            );
            this.files[index] = output.file;
        } else if (output.type === 'rejected' && typeof output.file !== 'undefined') {
            this.alertService.error('File type is not correct!');
        } else if (output.type === 'removed') {
            // remove file from array when removed
            this.files = this.files.filter((file: UploadFile) => file !== output.file);
        } else if (output.type === 'dragOver') {
            this.dragOver = true;
        } else if (output.type === 'dragOut') {
            this.dragOver = false;
        } else if (output.type === 'drop') {
            this.dragOver = false;
        } else if (output.file.progress.data.percentage === 100) {
            this.getUserFiles();
        }
    }

    startUpload(): void {
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));

        this.uploadEvent = {
            type: 'uploadAll',
            url: `${environment.contentAPIUrl}/api/v1/user/file/`,
            method: 'POST',
            headers: { Authorization: `Bearer ${currentUser.access_token}` },
            data: { foo: 'bar' },
        };

        this.uploadInput.emit(this.uploadEvent);
    }

    removeFile(id: string): void {
        this.uploadInput.emit({ type: 'remove', id });
    }

    deleteFile(fileID: string): void {
        this.userFilesService.deleteUserFile(fileID).subscribe(
            () => {
                this.getUserFiles();
            },
            (error) => {
                this.alertService.error(error.message);
            },
        );
    }

    getFileContent(fileID: string): void {
        this.userFilesService.getUserFile(fileID).subscribe(
            (response: UserFileResponse) => {
                this.selectedFileResponse = response;

                let uploadedFileMarkers = this.selectedFileResponse.rows.map((item) => {
                    return [item.latitude, item.longitude, item.name];
                });

                // let latitudeArray = this.selectedFileResponse.rows.map((item) => {
                //     return item.latitude;
                // });
                //
                // let longitudeArray = this.selectedFileResponse.rows.map((item) => {
                //     return item.longitude;
                // });
                //
                // let minLatPoint = Math.min(...latitudeArray);
                // let maxLonPoint = Math.max(...longitudeArray);
                //
                // let boundryPoints = [];
                //
                // boundryPoints.push(maxLonPoint, minLatPoint);

                this.myDataService.iterateMarkers(uploadedFileMarkers);
            },
            (error) => {
                this.alertService.error(error.message);
            },
        );
    }

    patchFileAlias(fileID: string, fileAlias: string): void {
        this.userFilesService.patchUserFile(fileID, fileAlias).subscribe(
            (response: PatchFileResponse) => {
                if (response.Updated === 1) {
                    this.selectedFileAlias = fileAlias;
                    // console.log('Changed the alias as:', this.selectedFileAlias);
                    this.getUserFiles();
                }
            },
            (error) => {
                this.alertService.error(error.message);
            },
        );
    }

    public openEditFileNameModal(fileID: string, fileAlias: string): void {
        this.selectedFileAlias = fileAlias;

        this.modalService.open(this.editFileNameModalContent, this.modalOption).result.then(
            (result) => {
                // console.log(`Closed with: ${result}`);
                fileAlias = this.selectedFileAlias;
                this.patchFileAlias(fileID, fileAlias);
            },
            (reason) => {
                // console.log(`Dismissed ${this.getDismissReason(reason)}`);
            },
        );
    }

    public setSelectedLayerState(index: number, fileID: string): void {
        if (
            this.userFiles[index].selectedFileItem ||
            this.myDataService.selectedUploadMyDataItem ||
            this.myDataService.selectedUploadMyDataItems
        ) {
            this.userFiles[index].selectedFileItem = false;
            this.myDataService.selectedUploadMyDataItem = this.userFiles[index].selectedFileItem;

            this.mapService.map.removeLayer(this.myDataService.markerLayerContainer);
            console.log('selectedUploadMyDataItem is false');
        } else if (
            !this.userFiles[index].selectedFileItem ||
            !this.myDataService.selectedUploadMyDataItem ||
            !this.myDataService.selectedUploadMyDataItems
        ) {
            this.userFiles[index].selectedFileItem = true;
            this.myDataService.selectedUploadMyDataItem = this.userFiles[index].selectedFileItem;

            this.getFileContent(fileID);

            console.log('selectedUploadMyDataItem is true');
        }
    }

    public setSelectedLayersState(): void {
        if (!this.myDataService.selectedUploadMyDataItems) {
            for (let userFile of this.userFiles) {
                let fileID = userFile.fileid;

                this.myDataService.selectedUploadMyDataItems = userFile.selectedFileItem;

                this.myDataService.selectedUploadMyDataItems = true;

                if (this.myDataService.selectedUploadMyDataItems) {
                    this.getFileContent(fileID);
                }
            }
        } else {
            console.log('myDataService.selectedUploadMyDataItems are false');
            this.myDataService.selectedUploadMyDataItems = false;
            this.mapService.map.removeLayer(this.myDataService.markerLayerContainer);
        }
    }

    private getDismissReason(reason: {}): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }
}
