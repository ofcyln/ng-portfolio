import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../../models/users';
import { environment } from '../../../environments/environment';
import { map, tap, share } from 'rxjs/operators';
import { Observable, BehaviorSubject } from 'rxjs';

interface UserResponse {
    code: number;
    message: string;
    data: User;
}

@Injectable()
export class UserService {
    private _user: User;
    private user$ = new BehaviorSubject(this._user);

    constructor(public http: HttpClient) {}

    public get user(): Observable<User> {
        if (this._user) {
            return this.user$;
        }

        this.getUser()
            .pipe(
                map((userResponse: UserResponse) => {
                    return userResponse.data;
                }),
                share(),
            )
            .subscribe((user: User) => {
                this.user$.next(user);
            });

        return this.user$;
    }

    public setUser(user: User) {
        this._user = user;
        this.user$.next(user);
    }

    private getUser() {
        return (
            this.http
                .get<UserResponse>(`${environment.baseAPIUrl}/users/me`)
                // http observable doner, subscribe cagirilmadikca calismaz
                .pipe(
                    tap((userResponse: UserResponse) => {
                        this._user = userResponse.data;
                    }),
                )
        );
    }
}
