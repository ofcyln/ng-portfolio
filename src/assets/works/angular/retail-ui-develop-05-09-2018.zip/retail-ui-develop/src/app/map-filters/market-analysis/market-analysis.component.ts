import { Component, ElementRef, HostBinding, OnInit, ViewChild } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';
import { Settings } from 'daterangepicker';
import { DateRangeModel } from '../residence/residence.component';
import * as moment from 'moment';
import { ModalDismissReasons, NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { NgForm } from '@angular/forms';

export interface MarketAnalysis {
    title: string;
    id: number;
}

export interface DateRangeModel {
    start?: string | Date | moment.Moment;
    end?: string | Date | moment.Moment;
    label?: string;
}

@Component({
    selector: 'rdm-market-analysis',
    templateUrl: './market-analysis.component.html',
    styleUrls: ['./market-analysis.component.scss'],
    animations: [slideInLeftAnimation],
})
export class MarketAnalysisComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    @ViewChild('editPopularSearchsModalTemplate') editPopularSearchsModalContent: ElementRef;
    @ViewChild('savePopularSearchsModalTemplate') savePopularSearchsModalContent: ElementRef;
    modalOption: NgbModalOptions = {};

    public searchMarketAnalysis: string;

    public popularSearchs: MarketAnalysis[];

    public selectedAnalysisType = 'Select Analysis Type';
    public analysisTypes: MarketAnalysis[];

    public selectedRentMarket = 'Select Rent Market';
    public rentMarkets: MarketAnalysis[];

    public selectedRegionZone = 'Select Region';
    public regionZones: MarketAnalysis[];

    public selectedDataType = 'Select Data Type';
    public dataTypes: MarketAnalysis[];

    // daterangepicker
    public selectedStartDateRange: DateRangeModel = {};
    public selectedEndDateRange: DateRangeModel = {};
    public dateRangePickerSettings: Settings;

    constructor(public modalService: NgbModal) {}

    ngOnInit() {
        this.modalOption.backdrop = 'static';
        this.modalOption.keyboard = false;

        this.initDateRangePickerSettings();
        this.initMarketAnalysisData();
    }

    public openEditPopularSearchsModal() {
        this.modalService.open(this.editPopularSearchsModalContent, this.modalOption).result.then(
            (result) => {
                console.log(`Closed with: ${result}`);
            },
            (reason) => {
                console.log(`Dismissed ${this.getDismissReason(reason)}`);
            },
        );
    }

    public openSavePopularSearchsModal() {
        this.modalService.open(this.savePopularSearchsModalContent, this.modalOption).result.then(
            (result) => {
                console.log(`Closed with: ${result}`);
            },
            (reason) => {
                console.log(`Dismissed ${this.getDismissReason(reason)}`);
            },
        );
    }

    public setMarketAnalysisFilter(marketAnalysisForm: NgForm) {
        console.log(this.searchMarketAnalysis);
    }

    public onDateSelection(value: DateRangeModel, dateRangeModel?: DateRangeModel): void {
        dateRangeModel.start = value.start;
        dateRangeModel.end = value.end;
        dateRangeModel.label = value.label;
    }

    private initMarketAnalysisData(): void {
        this.popularSearchs = [
            {
                title: 'Satış Piyasası',
                id: 1,
            },
            {
                title: 'Yatırımlar',
                id: 2,
            },
            {
                title: 'İnşaat Göstergeleri',
                id: 3,
            },
        ];

        this.analysisTypes = [
            {
                title: 'Satış Piyasası',
                id: 1,
            },
            {
                title: 'Kira Piyasası',
                id: 2,
            },
            {
                title: 'Yatırımlar',
                id: 3,
            },
            {
                title: 'Demografik Veriler',
                id: 4,
            },
            {
                title: 'İnşaat Göstergeleri',
                id: 5,
            },
            {
                title: 'Finans ve Ekonomi Piyasası',
                id: 6,
            },
        ];

        this.rentMarkets = [
            {
                title: 'Satış Piyasası',
                id: 1,
            },
            {
                title: 'Kira Piyasası',
                id: 2,
            },
            {
                title: 'Yatırımlar',
                id: 3,
            },
            {
                title: 'Demografik Veriler',
                id: 4,
            },
            {
                title: 'İnşaat Göstergeleri',
                id: 5,
            },
            {
                title: 'Finans ve Ekonomi Piyasası',
                id: 6,
            },
        ];

        this.regionZones = [
            {
                title: 'Region 1',
                id: 1,
            },
            {
                title: 'Region 2',
                id: 2,
            },
        ];

        this.dataTypes = [
            {
                title: 'Data Type 1',
                id: 1,
            },
            {
                title: 'Data Type 2',
                id: 2,
            },
        ];
    }

    private initDateRangePickerSettings(): void {
        this.dateRangePickerSettings = {
            locale: {
                format: 'DD/MM/YYYY',
                separator: ' - ',
                customRangeLabel: 'Custom Range',
                applyLabel: 'Apply',
                cancelLabel: 'Cancel',
                weekLabel: 'W',
                daysOfWeek: ['Pz', 'Pzt', 'Sa', 'Çar', 'Per', 'Cu', 'Cst'],
                monthNames: [
                    'Ocak',
                    'Şubat',
                    'Mart',
                    'Nisan',
                    'Mayıs',
                    'Haziran',
                    'Temmuz',
                    'Ağustos',
                    'Eylül',
                    'Ekim',
                    'Kasım',
                    'Aralık',
                ],
                firstDay: 1,
            },
            drops: 'up',
            alwaysShowCalendars: false,
            showCustomRangeLabel: true,
            linkedCalendars: false,
            showDropdowns: true,
            ranges: {
                Today: [moment(), moment()],
                Yesterday: [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [
                    moment()
                        .subtract(1, 'month')
                        .startOf('month'),
                    moment()
                        .subtract(1, 'month')
                        .endOf('month'),
                ],
            },
        };
    }

    private getDismissReason(reason: {}): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }
}
