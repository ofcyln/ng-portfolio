import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeadSummaryComponent } from './head-summary/head-summary.component';
import { HeadScoreComponent } from './head-score/head-score.component';
import { CloseButtonComponent } from './close-button/close-button.component';
import { StreetViewComponent } from './street-view/street-view.component';
import { TabSectionsComponent } from './tab-sections/tab-sections.component';
import { QridActionsComponent } from './qrid-actions/qrid-actions.component';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClientModule } from '@angular/common/http';
import { TabSectionsModule } from './tab-sections/tab-sections.module';
import { DensityComponent } from './density/density.component';
import { QridActionsModule } from './qrid-actions/qrid-actions.module';

@NgModule({
    imports: [
        CommonModule,
        NgbModule,
        TranslateModule,
        FormsModule,
        HttpClientModule,
        TabSectionsModule,
        QridActionsModule,
    ],
    declarations: [
        HeadSummaryComponent,
        HeadScoreComponent,
        CloseButtonComponent,
        StreetViewComponent,
        TabSectionsComponent,
        QridActionsComponent,
        DensityComponent,
    ],
    exports: [
        HeadSummaryComponent,
        HeadScoreComponent,
        CloseButtonComponent,
        StreetViewComponent,
        TabSectionsComponent,
        QridActionsComponent,
        DensityComponent,
    ],
})
export class QridDetailsModule {}
