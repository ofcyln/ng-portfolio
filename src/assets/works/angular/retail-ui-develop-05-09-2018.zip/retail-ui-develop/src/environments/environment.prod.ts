export const environment = {
    production: true,
    baseAPIUrl: 'https://userservice.reidin.com',
    geoserverUrl: 'https://rdevgeoserver.reidin.com:8443',
    contentAPIUrl: 'https://retail-map-api-dev.reidin.com',
    clientSecret:
        'cmViaXM6ZVV4VWNucEZhVkI0Wm5VMVkyNU9hRVJWU2xKQmQxbFJUSHAzUkU1cFVVWkZTVzFPTjFKclRHaDJkWFZVY1V4eQ==',
};

// TODO: baseAPIUrl: 'https://account.reidin.com',
