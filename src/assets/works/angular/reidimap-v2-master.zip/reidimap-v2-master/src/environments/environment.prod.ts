export const environment = {
    production: true,
    apiUrl: 'https://map.reidin.com/api/v1/json',
};
