import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MapComponent } from './map.component';
import { MapFiltersModule } from '../map-filters/map-filters.module';

@NgModule({
    imports: [CommonModule, MapFiltersModule],
    declarations: [MapComponent],
    entryComponents: [MapComponent],
    exports: [MapComponent, MapFiltersModule],
})
export class MapModule {}
