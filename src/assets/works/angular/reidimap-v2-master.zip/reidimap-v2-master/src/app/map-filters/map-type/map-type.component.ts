import { Component, HostBinding, OnInit } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';

@Component({
    selector: 'rdm-map-type',
    templateUrl: './map-type.component.html',
    styleUrls: ['./map-type.component.scss'],
    animations: [slideInLeftAnimation],
})
export class MapTypeComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    constructor() {}

    ngOnInit() {}
}
