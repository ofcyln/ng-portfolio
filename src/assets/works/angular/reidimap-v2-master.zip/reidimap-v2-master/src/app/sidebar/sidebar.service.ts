import { Injectable } from '@angular/core';

export interface MenuElement {
    title: string;
    icon: string;
    isPrimary: boolean;
    route: string;
    badge: number;
    isActive?(): boolean;
}

@Injectable()
export class SidebarService {
    public getMenuElements(): MenuElement[] {
        return [
            {
                title: 'main.general.tooltips.residence',
                icon: 'ricon-projeler',
                route: 'residence',
                isPrimary: true,
                badge: null,
                /*isActive: () => {
        return true;
      },*/
            },
            {
                title: 'main.general.tooltips.office',
                icon: 'ricon-briefcase',
                route: 'office',
                isPrimary: true,
                badge: null,
            },
            {
                title: 'main.general.tooltips.market-analysis',
                icon: 'ricon-pazar-analizi',
                route: 'market-analysis',
                isPrimary: true,
                badge: null,
            },
            {
                title: 'main.general.tooltips.urban-planning',
                icon: 'ricon-kent-planlama',
                route: 'urban-planning',
                isPrimary: true,
                badge: null,
            },
            {
                title: 'main.general.tooltips.transactions',
                icon: 'ricon-transactions',
                route: 'transaction',
                isPrimary: true,
                badge: null,
            },
            {
                title: 'main.general.tooltips.listings',
                icon: 'ricon-listings',
                route: 'listings',
                isPrimary: true,
                badge: null,
            },
            {
                title: 'main.general.tooltips.pois',
                icon: 'ricon-onemli-noktalar',
                route: 'poi',
                isPrimary: true,
                badge: 2,
            },
            {
                title: 'main.general.tooltips.map-types',
                icon: 'ricon-harita-tipi',
                route: 'map-type',
                isPrimary: false,
                badge: null,
            },
            {
                title: 'main.general.tooltips.customization',
                icon: 'ricon-lejand',
                route: 'customization',
                isPrimary: false,
                badge: null,
            },
            // {
            //     title: 'main.general.tooltips.layers',
            //     icon: 'ricon-katmanlar',
            //     route: 'layer',
            //     isPrimary: false,
            //     badge: null,
            // },
            {
                title: 'main.general.tooltips.my-workspace',
                icon: 'ricon-folder',
                route: 'workspace',
                isPrimary: false,
                badge: null,
            },
        ];
    }
}
