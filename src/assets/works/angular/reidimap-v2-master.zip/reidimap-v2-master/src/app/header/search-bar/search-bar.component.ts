import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { CompleterData, CompleterService } from 'ng2-completer';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';

export interface City {
    title: string;
    selected: boolean;
}

export interface County {
    title: string;
    selected: boolean;
}

export interface District {
    title: string;
    selected: boolean;
}

@Component({
    selector: 'rdm-search-bar',
    templateUrl: './search-bar.component.html',
    styleUrls: ['./search-bar.component.scss'],
})
export class SearchBarComponent implements OnInit {
    public selectedCity = 'Select City';
    public selectedCounty = 'Select County';
    public selectedDistrict = 'Select District';

    public searchStr: string;
    public dataService: CompleterData;

    public cities = [
        { title: 'İstanbul', selected: false },
        { title: 'İzmir', selected: false },
        { title: 'Hatay', selected: false },
    ];
    public counties = [
        { title: 'Kadıköy', selected: false },
        { title: 'Şişli', selected: false },
        { title: 'Sarıyer', selected: false },
    ];
    public districts = [
        { title: 'Feneryolu', selected: false },
        { title: '19 Mayıs', selected: false },
        { title: 'Cadde Bostan', selected: false },
    ];
    public searchData = [
        {
            firstName: 'Mehmet Nuri',
            surname: 'Karaküçük',
            image: '/assets/img/search-google-icon.png',
        },
        {
            firstName: 'Osman Fikret',
            surname: 'Ceylan',
            image: '/assets/img/search-google-icon.png',
        },
        {
            firstName: 'Fikret',
            surname: 'Ceylan',
            image: '/assets/img/search-reidin-icon.png',
        },
        {
            firstName: 'Fikret Osman',
            surname: 'Ceylan',
            image: '/assets/img/search-google-icon.png',
        },
        {
            firstName: 'Gökhan',
            surname: 'Asan',
            image: '/assets/img/search-google-icon.png',
        },
        {
            firstName: 'Deniz',
            surname: 'Sağlam',
            image: '/assets/img/search-reidin-icon.png',
        },
        {
            firstName: 'Deniz',
            surname: 'Subaşı',
            image: '/assets/img/search-google-icon.png',
        },
    ];
    @ViewChild('regionSelectModalTemplate')
    regionSelectModalContent: ElementRef;
    // soldaki html de kullanılan isim,
    // diğer regionSelectModalContent sınıftaki ismi, bunları eşleştiriyoruz

    constructor(
        public completerService: CompleterService,
        public modalService: NgbModal,
        public translateService: TranslateService,
    ) {}

    ngOnInit() {
        this.dataService = this.completerService
            .local(this.searchData, 'firstName,surname', 'firstName,surname')
            .imageField('image');

        this.translateService
            .stream('main.general.autocomplete.choose-city')
            .subscribe(translatedText => (this.selectedCity = translatedText));

        this.translateService
            .stream('main.general.autocomplete.choose-county')
            .subscribe(
                translatedText => (this.selectedCounty = translatedText),
            );

        this.translateService
            .stream('main.general.autocomplete.choose-district')
            .subscribe(
                translatedText => (this.selectedDistrict = translatedText),
            );

        // TODO: burdan sonrasini ders calistiktan sonra sil

        /*.subscribe(function(translatedText) {
              this.selectedCity = translatedText;
          });*/
        /*.subscribe((translatedText) => {
            this.selectedCity = translatedText;
          });*/
        // .subscribe(translatedText => this.selectedCity = translatedText);

        // translate service, method chaining nasil calisiyor

        // let translateService = {
        //     deger: '',
        //     translateEdilecekKey: '',
        //     stream: function(translateEdilecekKey: string) {
        //         this.translateEdilecekKey = translateEdilecekKey;
        //         return this;
        //     },
        //     translateEt: function(translateEdilecekKey: string) {
        //         let translateEdilecekKeyDegeri = 'translate edildi';
        //         return translateEdilecekKeyDegeri;
        //     },
        //     subscribe: function(translateSonrasiCagrilacakCallback: Function) {
        //         this.deger = this.translateEt(this.translateEdilecekKey);
        //         translateSonrasiCagrilacakCallback(this.deger);
        //     },
        // };
        //
        // translateService
        //     .stream('main.general.placeholders.search-in-reidimap')
        //     .subscribe(function(cevrilenDeger: string) {
        //         console.log(cevrilenDeger);
        //     });

        // fonksiyon callback nasil calisir
        // let fonksiyonum = function(a: number, b: number, c: number) {
        //     console.log(c, a, b);
        // };
        // fonksiyonum = (a: number, b: number, c: number) => {
        //     console.log(b);
        // };
        // fonksiyonum = a => console.log(a);
        // this.callbackCagiranMetod(fonksiyonum);
    }

    // TODO: bunu calistiktan sonra sil
    // public callbackCagiranMetod(herhangiBisey: Function) {
    //     herhangiBisey(5, 3, 2, 1);
    // }

    public openRegionSelectModal() {
        this.modalService.open(this.regionSelectModalContent).result.then(
            result => {
                console.log(`Closed with: ${result}`); // baş ve sondaki karakterler backtick multiline string girilmesini sağlar
            },
            reason => {
                console.log(`Dismissed ${this.getDismissReason(reason)}`);
            },
        );
    }

    public setSelectedCity(city: City) {
        this.selectedCity = city.title;
    }

    public setSelectedCounty(county: County) {
        this.selectedCounty = county.title;
    }

    public setSelectedDistrict(district: District) {
        this.selectedDistrict = district.title;
    }

    private getDismissReason(reason: {}): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }
}
