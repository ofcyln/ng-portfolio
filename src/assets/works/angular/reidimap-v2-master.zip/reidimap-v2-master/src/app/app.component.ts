import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UserService } from './auth/user/user.service';

@Component({
    selector: 'rdm-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css'],
})
export class AppComponent {
    public title = 'ReidiMap';

    constructor(
        public translate: TranslateService,
        public userService: UserService,
    ) {
        translate.addLangs(['en', 'tr']);
        translate.setDefaultLang(userService.userSettings.language);
    }
}
