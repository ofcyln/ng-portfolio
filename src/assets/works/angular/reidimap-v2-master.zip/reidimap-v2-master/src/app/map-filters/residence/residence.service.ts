import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { UserService } from '../../auth/user/user.service';

export interface V1ApiResponse<T> {
    // bu interfacei kullanırken içine generik tip geçilecek
    code: number;
    data: T; // generic type
    debug: object;
    info: object;
    status: boolean;
}

export interface StringNumberMap {
    [key: string]: number;
}

export interface Range {
    min: number;
    max: number;
}

export interface TwoDimensionalStringNumberMap {
    [key: string]: StringNumberMap;
}

export interface ProjectsResponse {
    CityID: StringNumberMap;
    GLA: Range;
    NoOfRooms: Range;
    ProjectType: StringNumberMap;
    StatusID: StringNumberMap;
}

export interface PropertiesResponse {
    CityID: StringNumberMap;
    GLA: Range;
    NoOfUnits: Range;
    OccupancyRate: Range;
    PropertyStatusID: StringNumberMap;
    SubTypeID: TwoDimensionalStringNumberMap;
}

@Injectable()
export class ResidenceService {
    public callbackParam = 'JSONP_CALLBACK';

    constructor(public http: HttpClient, public userService: UserService) {}

    public getProperties() {
        const requestParams = this.setJsonpParam(this.getSettings());

        const requestUrl = `${environment.apiUrl}/properties/filter/?${requestParams.toString()}`;

        return this.http
            .jsonp(requestUrl, this.callbackParam)
            .map(
                (response: V1ApiResponse<PropertiesResponse>) =>
                    <PropertiesResponse>this.mapData(response),
            )
            .toPromise();
    }

    public getProjects() {
        const requestParams = this.setJsonpParam(this.getSettings());

        const requestUrl = `${environment.apiUrl}/projects/filter/?${requestParams.toString()}`;

        return this.http
            .jsonp(requestUrl, this.callbackParam)
            .map(
                (response: V1ApiResponse<ProjectsResponse>) =>
                    <ProjectsResponse>this.mapData(response),
            )
            .toPromise();
    }

    public objectToGroupMultiselectData(object: TwoDimensionalStringNumberMap) {
        return Object.keys(object).reduce((acc, currValue) => {
            return acc.concat(
                Object.keys(object[currValue]).map(secondary => {
                    return {
                        itemName: secondary,
                        id: object[currValue][secondary],
                        category: currValue,
                    };
                }),
            );
        }, []);
    }

    public objectToMultiselectData(object: StringNumberMap) {
        return Object.keys(object).map(item => {
            return { itemName: item, id: object[item] };
        });
    }

    private setJsonpParam(params: URLSearchParams): URLSearchParams {
        params.set('callback', this.callbackParam);
        return params;
    }

    private mapData(response: V1ApiResponse<{}>) {
        return response.data;
    }

    private getSettings(): URLSearchParams {
        const userSettings = this.userService.userSettings;

        const requestParams = new URLSearchParams();
        requestParams.set('currency', userSettings.currency);
        requestParams.set('measurement', userSettings.measurement);
        requestParams.set('CountryID', userSettings.countryId.toString());
        requestParams.set('CountryCode', userSettings.countryCode);
        requestParams.set('locale', userSettings.locale);
        return requestParams;
    }
}
