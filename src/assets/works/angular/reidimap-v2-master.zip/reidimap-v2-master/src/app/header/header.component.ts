import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'rdm-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
    displayMonths = 2;
    navigation = 'select';

    constructor() {}

    ngOnInit() {}
}
