import { RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from './routing/not-found.component';
import { NgModule } from '@angular/core';
import { SelectivePreloadingStrategy } from './routing/selective-preloading-strategy';

const appRoutes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: '**', component: PageNotFoundComponent },
];

@NgModule({
    imports: [
        RouterModule.forRoot(appRoutes, {
            enableTracing: false, // <-- debugging purposes only
            preloadingStrategy: SelectivePreloadingStrategy,
        }),
    ],
    declarations: [PageNotFoundComponent],
    exports: [RouterModule],
    providers: [SelectivePreloadingStrategy],
})
export class AppRoutingModule {}
