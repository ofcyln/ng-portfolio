import { Injectable } from '@angular/core';
import { StorageService } from '../../shared/storage.service';

export interface UserSettings {
    currency: string;
    measurement: string;
    countryId: number;
    countryCode: string;
    locale: string;
    language: string;
}

@Injectable()
export class UserService {
    constructor(public storageService: StorageService) {}

    public get userSettings(): UserSettings {
        const userSettings = this.getUserSettings();
        if (userSettings) {
            return userSettings;
        } else {
            return {
                currency: 'TRL',
                measurement: 'INT',
                countryId: 231,
                countryCode: 'TR',
                locale: 'tr_TR',
                language: 'en',
            };
        }
    }

    public set userSettings(settings: UserSettings) {
        this.setUserSettings(settings);
    }

    private setUserSettings(userSettings: UserSettings): void {
        this.storageService.setObject('userSettings', userSettings);
    }

    private getUserSettings(): UserSettings {
        return <UserSettings>this.storageService.getObject('userSettings');
    }
}
