import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from './sidebar.component';
import { SidebarService } from './sidebar.service';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
    imports: [CommonModule, RouterModule, NgbModule, TranslateModule],
    declarations: [SidebarComponent],
    entryComponents: [SidebarComponent],
    exports: [SidebarComponent],
    providers: [SidebarService],
})
export class SidebarModule {}
