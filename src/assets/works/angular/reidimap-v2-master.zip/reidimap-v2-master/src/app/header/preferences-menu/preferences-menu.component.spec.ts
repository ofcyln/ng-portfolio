import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreferencesMenuComponent } from './preferences-menu.component';

describe('PreferencesMenuComponent', () => {
    let component: PreferencesMenuComponent;
    let fixture: ComponentFixture<PreferencesMenuComponent>;

    beforeEach(
        async(() => {
            TestBed.configureTestingModule({
                declarations: [PreferencesMenuComponent],
            }).compileComponents();
        }),
    );

    beforeEach(() => {
        fixture = TestBed.createComponent(PreferencesMenuComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
