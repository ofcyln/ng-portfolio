import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { UserService, UserSettings } from '../user/user.service';

export interface Language {
    title: string;
    selected: boolean;
}

@Component({
    selector: 'rdm-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
    public selectedLanguage = 'Select Language';
    public languages: string[] = [];

    public isAuthenticated: boolean;
    public username: string;
    public password = '';

    public userSettings: UserSettings;

    constructor(
        public router: Router, // public router = new Router();
        public translate: TranslateService,
        public userService: UserService,
    ) {}

    ngOnInit() {
        this.isAuthenticated = true;

        this.username = 'admin@reidin.com';
        this.password = 'admin';

        this.languages = this.translate.getLangs();
        this.selectedLanguage = this.translate.getDefaultLang();
        console.log(this.translate.getLangs());

        this.userSettings = this.userService.userSettings;
    }

    public switchLanguage(language: string) {
        this.translate.use(language);
        this.selectedLanguage = language;
        this.userSettings.language = language;
        this.userService.userSettings = this.userSettings;
    }

    public onPasswordChange(value: string) {
        console.log(value);
    }

    public navigateToHomePage(f: NgForm) {
        console.log(f.value);
        console.log(this.username);
        console.log(this.password);
        if (f.valid && this.isAuthenticated) {
            this.router.navigate(['/home']);
        } else {
            f.resetForm();
        }
    }

    public setSelectedLanguage(language: Language) {
        this.selectedLanguage = language.title;
    }
}
