import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {
    ModalDismissReasons,
    NgbModal,
    NgbModalOptions,
} from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { UserService, UserSettings } from '../../auth/user/user.service';

export interface FeedbackType {
    title: string;
    id: number;
}

@Component({
    selector: 'rdm-preferences-menu',
    templateUrl: './preferences-menu.component.html',
    styleUrls: ['./preferences-menu.component.scss'],
})
export class PreferencesMenuComponent implements OnInit {
    @ViewChild('regionSelectModalTemplate')
    regionSelectModalContent: ElementRef;
    @ViewChild('languageSelectModalTemplate')
    languageSelectModalContent: ElementRef;
    @ViewChild('currencySelectModalTemplate')
    currencySelectModalContent: ElementRef;
    @ViewChild('measurementSelectModalTemplate')
    measurementSelectModalContent: ElementRef;
    @ViewChild('feedbackSelectModalTemplate')
    feedbackSelectModalContent: ElementRef;
    modalOption: NgbModalOptions = {};
    public selectedFeedbackType = 'Select';

    public userSettings: UserSettings;

    public feedbackTypes = [
        { title: 'Hata Bildirimi', id: 0 },
        { title: 'Öneri', id: 1 },
        { title: 'Talep', id: 2 },
        { title: 'Teşekkür', id: 3 },
    ];

    constructor(
        public modalService: NgbModal,
        public translate: TranslateService,
        public translateService: TranslateService,
        public userService: UserService,
    ) {}

    ngOnInit() {
        this.modalOption.backdrop = 'static';
        this.modalOption.keyboard = false;

        this.userSettings = this.userService.userSettings;

        this.translateService
            .stream('main.general.placeholders.choose')
            .subscribe(
                translatedText => (this.selectedFeedbackType = translatedText),
            );

        this.translateService
            .stream('main.views.header.feedback.submit-error')
            .subscribe(
                translatedText =>
                    (this.feedbackTypes[0].title = translatedText),
            );

        this.translateService
            .stream('main.views.header.feedback.suggestion')
            .subscribe(
                translatedText =>
                    (this.feedbackTypes[1].title = translatedText),
            );

        this.translateService
            .stream('main.views.header.feedback.wish')
            .subscribe(
                translatedText =>
                    (this.feedbackTypes[2].title = translatedText),
            );

        this.translateService
            .stream('main.views.header.feedback.thanks')
            .subscribe(
                translatedText =>
                    (this.feedbackTypes[3].title = translatedText),
            );
    }

    public switchLanguage(language: string) {
        this.translate.use(language);
    }

    public openRegionSelectModal() {
        this.modalService
            .open(this.regionSelectModalContent, this.modalOption)
            .result.then(
                result => {
                    console.log(`Closed with: ${result}`); // baş ve sondaki karakterler backtick multiline string girilmesini sağlar
                },
                reason => {
                    console.log(`Dismissed ${this.getDismissReason(reason)}`);
                },
            );
    }

    public openLanguageSelectModal() {
        this.modalService
            .open(this.languageSelectModalContent, this.modalOption)
            .result.then(
                result => {
                    console.log(`Closed with: ${result}`);
                },
                reason => {
                    console.log(`Dismissed ${this.getDismissReason(reason)}`);
                },
            );
    }

    public openCurrencySelectModal() {
        this.modalService
            .open(this.currencySelectModalContent, this.modalOption)
            .result.then(
                result => {
                    console.log(`Closed with: ${result}`);
                },
                reason => {
                    console.log(`Dismissed ${this.getDismissReason(reason)}`);
                },
            );
    }

    public openMeasurementSelectModal() {
        this.modalService
            .open(this.measurementSelectModalContent, this.modalOption)
            .result.then(
                result => {
                    console.log(`Closed with: ${result}`);
                },
                reason => {
                    console.log(`Dismissed ${this.getDismissReason(reason)}`);
                },
            );
    }

    public openFeedbackSelectModal() {
        this.modalService
            .open(this.feedbackSelectModalContent, this.modalOption)
            .result.then(
                result => {
                    console.log(`Closed with: ${result}`);
                },
                reason => {
                    console.log(`Dismissed ${this.getDismissReason(reason)}`);
                },
            );
    }

    // feedback type ı seçilince dropdown a basan fucntion
    public setSelectedFeedbackType(feedbackType: FeedbackType) {
        this.selectedFeedbackType = feedbackType.title;
    }

    private getDismissReason(reason: {}): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }
}
