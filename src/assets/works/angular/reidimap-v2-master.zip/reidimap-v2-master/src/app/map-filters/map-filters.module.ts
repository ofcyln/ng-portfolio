import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResidenceComponent } from './residence/residence.component';
import { OfficeComponent } from './office/office.component';
import { MarketAnalysisComponent } from './market-analysis/market-analysis.component';
import { UrbanPlanningComponent } from './urban-planning/urban-planning.component';
import { TransactionComponent } from './transaction/transaction.component';
import { PoiComponent } from './poi/poi.component';
import { WorkspaceComponent } from './workspace/workspace.component';
import { LayerComponent } from './layer/layer.component';
import { ListingsComponent } from './listings/listings.component';
import { MapTypeComponent } from './map-type/map-type.component';
import { CustomizationComponent } from './customization/customization.component';
import { Daterangepicker } from 'ng2-daterangepicker';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule } from '@angular/forms';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { NouisliderModule } from 'ng2-nouislider';
import { HttpClientJsonpModule, HttpClientModule } from '@angular/common/http';

@NgModule({
    imports: [
        CommonModule,
        Daterangepicker,
        NgbModule,
        TranslateModule,
        FormsModule,
        AngularMultiSelectModule,
        NouisliderModule,
        HttpClientModule,
        HttpClientJsonpModule,
    ],
    declarations: [
        ResidenceComponent,
        OfficeComponent,
        MarketAnalysisComponent,
        UrbanPlanningComponent,
        TransactionComponent,
        PoiComponent,
        WorkspaceComponent,
        LayerComponent,
        ListingsComponent,
        MapTypeComponent,
        CustomizationComponent,
    ],
    exports: [
        ResidenceComponent,
        OfficeComponent,
        MarketAnalysisComponent,
        UrbanPlanningComponent,
        TransactionComponent,
        PoiComponent,
        WorkspaceComponent,
        LayerComponent,
        ListingsComponent,
        MapTypeComponent,
        CustomizationComponent,
    ],
})
export class MapFiltersModule {}
