import { Component, OnInit } from '@angular/core';
import * as L from 'leaflet';
import 'leaflet.gridlayer.googlemutant';
import 'leaflet.heat';

@Component({
    selector: 'rdm-map',
    templateUrl: './map.component.html',
    styleUrls: ['./map.component.scss'],
})
export class MapComponent implements OnInit {
    public terrainMutant: L.gridLayer.GoogleMutant;
    public satelliteMutant: L.gridLayer.GoogleMutant;
    public roadmapMutant: L.gridLayer.GoogleMutant;
    public hybridMutant: L.gridLayer.GoogleMutant;

    public projects = L.tileLayer(
        // 'https://tiles-dev-{s}.reidin.com/project/{z}/{x}/{y}.json',
        'https://tiles-{s}.reidin.com/project/{z}/{x}/{y}.json',
        {
            attribution: '&copy; <a href="reidin.com">ReidiMap</a> Projects\'s',
        },
    );

    public heatmapData = L.tileLayer(
        'https://tiles-{s}.reidin.com/project-cluster/{z}/{x}/{y}.json',
        {
            attribution: '&copy; <a href="reidin.com">ReidiMap</a> Heatmap',
        },
    );

    public pois = L.tileLayer(
        'https://tiles-{s}.reidin.com/landmarks/{z}/{x}/{y}.png',
        {
            attribution: '&copy; <a href="reidin.com">ReidiMap</a> POI\'s',
        },
    );

    public poiInfos = L.tileLayer(
        'https://tiles-{s}.reidin.com/landmarks/{z}/{x}/{y}.grid.json',
        {
            attribution:
                '&copy; <a href="reidin.com">ReidiMap</a> POI\'s Infos',
        },
    );

    public ngOnInit() {
        this.initGoogleMutants();
        this.initLeafletMap();
    }

    private initLeafletMap() {
        let map = L.map('map', {
            zoomControl: false,
            center: L.latLng(41.022649536133, 29.040184936523),
            zoom: 12,
            minZoom: 4,
            maxZoom: 20,
            layers: [this.roadmapMutant],
        });

        L.control.zoom({ position: 'bottomright' }).addTo(map);

        L.control
            .layers(
                {
                    'Google Roadmap': this.roadmapMutant,
                    'Google Satellite': this.satelliteMutant,
                    'Google Terrain': this.terrainMutant,
                    'Google Hybrid': this.hybridMutant,
                },
                {
                    'Reidin POIs': this.pois,
                    'Reidin POI Infos': this.poiInfos,
                    'Reidin Projects': this.projects,
                    'Reidin Projects Heatmap': this.heatmapData,
                },
            )
            .addTo(map);
        L.control.scale().addTo(map);

        L.heatLayer(
            [
                [41.022649536133, 29.040184936523, 0.2],
                [41.022649536134, 29.040184936524, 0.5],
                [41.023649536134, 29.020184936524, 0.5],
            ],
            { radius: 25 },
        ).addTo(map);

        // L.marker([41.022649536133, 29.040184936523]).addTo(map).bindPopup('Location Name').openPopup();
    }

    private initGoogleMutants() {
        this.terrainMutant = this.getGoogleTile('terrain');
        this.satelliteMutant = this.getGoogleTile('satellite');
        this.roadmapMutant = this.getGoogleTile('roadmap');
        this.hybridMutant = this.getGoogleTile('hybrid');
    }

    private getGoogleTile(type: L.gridLayer.GoogleMutantType) {
        return L.gridLayer.googleMutant({
            type: type,
        });
    }
}
