import { Component, HostBinding, OnInit } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';

@Component({
    selector: 'rdm-layer',
    templateUrl: './layer.component.html',
    styleUrls: ['./layer.component.scss'],
    animations: [slideInLeftAnimation],
})
export class LayerComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    constructor() {}

    ngOnInit() {}
}
