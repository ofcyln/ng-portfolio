import { Component, HostBinding, OnInit } from '@angular/core';
import { slideInLeftAnimation } from '../../animations';

@Component({
    selector: 'rdm-customization',
    templateUrl: './customization.component.html',
    styleUrls: ['./customization.component.scss'],
    animations: [slideInLeftAnimation],
})
export class CustomizationComponent implements OnInit {
    @HostBinding('@routeAnimation') routeAnimation = true;
    @HostBinding('class') classes = 'filter-pane';

    constructor() {}

    ngOnInit() {}
}
