// TODO: remove typings once PR is merged and published to npm -  PR: https://github.com/DefinitelyTyped/DefinitelyTyped/pull/21716

import * as L from 'leaflet';

declare module 'leaflet' {
    type HeatLatLngTuple = [number, number, number];

    interface ColorGradientConfig {
        [key: number]: string;
    }

    interface HeatMapOptions {
        minOpacity?: number;
        maxZoom?: number;
        max?: number;
        radius?: number;
        blur?: number;
        gradient?: ColorGradientConfig;
    }

    interface HeatLayer extends TileLayer {
        setOptions(options: HeatMapOptions): HeatLayer;
        addLatLng(latlng: LatLng | HeatLatLngTuple): HeatLayer;
        setLatLngs(latlngs: Array<LatLng | HeatLatLngTuple>): HeatLayer;
    }

    function heatLayer(
        latlngs: Array<LatLng | HeatLatLngTuple>,
        options: HeatMapOptions,
    ): HeatLayer;
}
